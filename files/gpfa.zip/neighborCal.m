function posNeighbor = neighborCal(grid2Size,posMiss,neighbor,grid_rn,neighborMap)
    [posX1,posX2] = ind2sub2(grid2Size,posMiss);
    ii = (max(1,posX1-neighbor):min(posX1+neighbor,grid_rn))-posX1;
    jj = (max(1,posX2-neighbor):min(posX2+neighbor,grid_rn))-posX2;
    ss = combvec(ii,jj);
    idx = (sum(ss.^2,1) <= neighbor^2); ss = ss(:,idx); ss(1,:) = ss(1,:)+posX1; ss(2,:) = ss(2,:)+posX2; 
    posNeighbor = zeros(size(ss,2),1);
    for it = 1:length(posNeighbor)
        posNeighbor(it) = neighborMap(ss(1,it),ss(2,it));
    end
    posNeighbor = posNeighbor (posNeighbor ~= posMiss);
