function alpha = kron_mvprod_GPU(A,B,y,isTranspose)
% find alpha = A kron B * y
%     if nargin < 4
%         isTranspose = false;
%     end 
    if isTranspose
        y= gpuArray(reshape(y,size(B,2),[]));
        alpha = B*y*A';
    else
        y= gpuArray(reshape(y,size(B,1),[]));
        alpha = B'*y*A;
    end
    %alpha = alpha(:);
    alpha = gather(alpha(:));
