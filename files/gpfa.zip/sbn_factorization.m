function [samples] = sbn_factorization(X,Burnin,Collections)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hierarchical model: factorization
% X = U*(H.*V) + e;       X: N*D
% e ~ N(0, tau);     tau   ~ gamma(a_0, b_0)
% U_n ~ N(0, alpha); alpha ~ gamma(c_0, d_0)
% V_d ~ N(0, beta);  beta  ~ gamma(c_0, d_0)
% H ~ Bernoulli(Phi2);
% Phi2 = Sigmoid(U2*(H2.*V2) + c2)
% H2 ~ Bernoulli(Phi3);
% Phi3 = Sigmoid(c3)

% Comments: we set alpha as a vetor of 1's;
% Input:
%
% X: data
% Burnin, number of burn-in iterations
% Collections, number of collected samples
%
% Output:
%
% samples: collected samples,
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if ~exist('Burnin','var')
    Burnin = 1000;
end
if ~exist('Collections','var')
    Collections = 1000;
end

%% hyperparameters
a_0 = 2;
b_0 = 2;
c_0 = 2;
d_0 = 2;
e_0 = 2;
f_0 = 2;

[K0, N] = size(X);

% factorized layer
K1 = 20;
tau   = rand(1, 1);
alpha = ones(K1, 1); %rand(K, 1);
beta  = rand(K1, 1);

U = randn(K1, N);
V = randn(K1, K0);
H = rand(K1, N)>0.5;

% hidden layer
K2 = 10;
S2 = randn(K2, N);
W2 = randn(K2, K1);
H2 = rand(K2, N)>0.5;
c2 = randn(K1, 1);
c3 = randn(K2, 1); 

samples.tau     = cell(1,Collections);
samples.alpha   = cell(1,Collections);
samples.beta    = cell(1,Collections);
samples.U       = cell(1, Collections);
samples.V       = cell(1, Collections);
samples.X       = cell(1, Collections);

samples.S2       = cell(1, Collections);
samples.W2       = cell(1, Collections);
samples.H2       = cell(1, Collections);
samples.c2       = cell(1, Collections);
samples.c3       = cell(1, Collections);


TAU     = zeros(1, Collections);
ALPHA   = zeros(K1, Collections);
BETA    = zeros(K1, Collections);

% load('fa_uv.mat');
% H = ones(size(H));

for iter=1:Burnin+Collections

    %% shallow model
    % sample tau
    tau = gamrnd(a_0 + N*K0/2, 1./(b_0 + sum(sum((X - V'*(H.*U) ).^2))/2) );
   
    % sample alpha
    % alpha  = gamrnd(c_0 + N/2, d_0 + sum(U.^2,2)/2);
    
    % sample beta
    beta = gamrnd(e_0 + K0/2, 1./(f_0 + sum(V .^2,2)/2) );
    
    % sample H
    Phi2 = bsxfun(@plus, W2'*(H2.*S2), c2);  % ones(K1,N); 
    res1 =  X - V'*(H.*U);
    for k = 1:K1 
        res1 =  res1 + V(k,:)'*(H(k,:).*U(k,:)) ;
        T    = Phi2(k,:) + tau/2 *sum( (2*res1 - V(k,:)'*U(k,:)) .* (V(k,:)'*U(k,:)),1);
        prob = 1./(1+exp(-T));
        H(k,:) = sparse( rand(1,N) < prob );
        res1 =  res1 - V(k,:)'*(H(k,:).*U(k,:)) ;
    end;    
    
    res1 =  X - V'*(H.*U);
    % sample U
    for k = 1:K1 
        res1 =  res1 + V(k,:)'*(H(k,:).*U(k,:)) ;
        Vpsi = bsxfun(@times,(V(k,:)'*H(k,:)),tau);
        invSigmaU = bsxfun(@plus, beta(k), sum(Vpsi.*(V(k,:)'*H(k,:)),1) );
        MuU = sum(Vpsi.*res1,1)./invSigmaU;
        U(k,:) = (MuU + randn(1,N)./sqrt(invSigmaU));
        res1 =  res1 - V(k,:)'*(H(k,:).*U(k,:)) ;
    end 

    % sample V
    res1 =  X - V'*(H.*U);
    for k = 1:K1 
        res1 =  res1 + V(k,:)'*(H(k,:).*U(k,:)) ;
        Upsi = bsxfun(@times,(U(k,:).*H(k,:)),tau);
        invSigmaV = bsxfun(@plus, alpha(k), sum(Upsi.*(U(k,:).*H(k,:)),2) );
        MuV = sum(bsxfun(@times, Upsi,res1),2)./invSigmaV;
        V(k,:) = (MuV' + randn(1,K0)./sqrt(invSigmaV));
        res1 =  res1 - V(k,:)'*(H(k,:).*U(k,:)) ;
    end     
    
    %% sample the deep model

    % top layer
    if 1
    % (0.0). update the auxilart variable gamma2
    Xmat = c3; % K1*n
    Xvec = repmat(Xmat,N,1);
    gamma2vec = PolyaGamRndTruncated(ones(K2*N,1),Xvec,20);
    gamma2 = reshape(gamma2vec,K2,N);

    % (0.1). update the top layer C
    sigmaC = 1./(sum(gamma2,2)+1)';
    muC = sigmaC.*(sum(H2,2)'-0.5);
    c3 = normrnd(muC,sqrt(sigmaC))';
    
    % W2*(H2*S2) + c2;    
    % (1.1). update the auxilart variable gamma1
    Xmat = bsxfun(@plus,W2'*(H2.*S2),c2); % K1*n
    Xvec = reshape(Xmat,K1*N,1);
    gamma1vec = PolyaGamRndTruncated(ones(K1*N,1),Xvec,20);
    gamma1 = reshape(gamma1vec,K1,N);
       
    % (1.1). update S2
    
    res2 = bsxfun(@plus, W2'*(H2.*S2), c2);
    for k = 1:K2 
        res2 = ( res2 - W2(k,:)'*(H2(k,:).*S2(k,:)) );
        Wpsi = W2(k,:)'*H2(k,:);
        invSigmaS = bsxfun(@plus, 1, sum(Wpsi.*(W2(k,:)'*H2(k,:)),1) );
        MuS = sum( (H-0.5- res2.*gamma1).* Wpsi, 1)./invSigmaS ;
        S2(k,:) = (MuS + randn(1,N)./invSigmaS);
        res2 = ( res2 + W2(k,:)'*(H2(k,:).*S2(k,:)) );
    end
    
    % (1.2). update W2
    res2 = bsxfun(@plus, W2'*(H2.*S2), c2);
    for k = 1:K2  
        res2 = ( res2 - W2(k,:)'*(H2(k,:).*S2(k,:)) );
        HS2  = S2(k,:).*H2(k,:);
        invSigmaW = bsxfun(@plus, 1, sum(HS2.*(S2(k,:).*H2(k,:)),2) );
        MuW = sum( bsxfun(@times, (H-0.5- res2.*gamma1) ,HS2) , 2)./invSigmaW;
        W2(k,:) = (MuW' + randn(1,K1)./invSigmaW);
        res2 = ( res2 + W2(k,:)'*(H2(k,:).*S2(k,:)) );
    end;

    
    % (1.3). update H2
    res2 = bsxfun(@plus, W2'*(H2.*S2), c2);
    for k = 1:K2       
        res2 = ( res2 - W2(k,:)'*(H2(k,:).*S2(k,:)) );
        WS2  = W2(k,:)'*S2(k,:);
        vec1 = sum(WS2 .* H, 1) + c3(k);  
        vec2 = sum(WS2 + bsxfun(@times,gamma1, 2*res2.*WS2 + WS2.^2))/2; % 1*n
        logh = vec1 - vec2 ; % 1*n 
        probh = exp(logh)./(exp(logh)+1); % 1*n 
        H2(k,:) = (probh>rand(1));
        res2 = ( res2 + W2(k,:)'*(H2(k,:).*S2(k,:)) );
    end;
    
    % (1.4). update c2
    sigmaC = 1./(sum(gamma1,2)+1);
    muC = sigmaC.*sum(H-0.5-gamma1.*(W2'*(H2.*S2)),2);
    c2 = normrnd(muC,sqrt(sigmaC));           
    end
    
    % collect the result
    TAU(1,iter)    = tau;
    ALPHA(:, iter) = alpha;
    BETA(:, iter)  = beta;

    % trace plot
    if 0
    if mod(iter,10)==0
        subplot(5,1,1);plot(max(1,iter-Burnin):iter,TAU(1,max(1,iter-Burnin):iter));
        xlim([iter-Burnin,iter]); title('$\tau$','interpreter', 'latex')
        subplot(5,1,2);plot(max(1,iter-Burnin):iter,ALPHA(1,max(1,iter-Burnin):iter));
        xlim([iter-Burnin,iter]); title('$\alpha_1$','interpreter', 'latex')
        subplot(5,1,3);plot(max(1,iter-Burnin):iter,ALPHA(2,max(1,iter-Burnin):iter));
        xlim([iter-Burnin,iter]); title('$\alpha_2$','interpreter', 'latex')
        subplot(5,1,4);plot(max(1,iter-Burnin):iter,BETA(1,max(1,iter-Burnin):iter));
        xlim([iter-Burnin,iter]); title('$\beta_1$','interpreter', 'latex')
        subplot(5,1,5);plot(max(1,iter-Burnin):iter,BETA(2,max(1,iter-Burnin):iter));
        xlim([iter-Burnin,iter]); title('$\beta_2$','interpreter', 'latex')
        drawnow
    end
    end
    
    if iter>Burnin
        samples.tau{iter-Burnin}     = tau;
        samples.alpha{iter-Burnin}   = alpha;
        samples.beta{iter-Burnin}    = beta;
        samples.U{iter-Burnin}       = U;
        samples.H{iter-Burnin}       = H;
        samples.V{iter-Burnin}       = V;      
    end
    
    data_m = V'*(H.*U);
    mse = sum(sum((data_m - X).^2))/(N*K0);
    disp(['Iter' num2str(iter)  ', MSE: ' num2str(mse) ]);
end