function sim_sbn=()
K = 25; 
p = 25;
ntrain = 1000;
W = randn(p,K);
Htrain = zeros(K,ntrain);
Vtrain = zeros(p,ntrain);
sigmoid = @(x) (1./(1+exp(-x)));
c = rand(p,1);
b = rand(K,1); 

for n = 1:ntrain
    Htrain(:,n) = (sigmoid(b) > rand(K,1));
    Vtrain(:,n) = (sigmoid(W*Htrain(:,n) + c) > rand(p,1));
end

