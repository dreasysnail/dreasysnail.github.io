function alpha = kron_mvprod_3D(A,B,C,y,isTranspose)
% find alpha = A kron B * y
% istranspose A,B
%     if nargin < 4
%         isTranspose = false;
%     end 
    if ~isTranspose
        y= reshape(y,size(C,2),[]);
        alpha = C*y;
        alpha = reshape(alpha',size(B,2),[]);
        alpha = B*alpha;
        alpha = reshape(alpha',size(A,2),[]);
        alpha = (A*alpha)';
    else
        y= reshape(y,size(C,1),[]);
        alpha = C'*y;
        alpha = reshape(alpha',size(B,1),[]);
        alpha = B'*alpha;
        alpha = reshape(alpha',size(A,1),[]);
        alpha = (A'*alpha)';
    end
    alpha = alpha(:);
