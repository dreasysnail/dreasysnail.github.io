function hyp = ARD_gp(hyp, y)
    x0(1) = hyp.theta; x0(2) = hyp.var;
    options = optimset('Largescale','off','Display','none','TolFun',1e-4);
    lb = [0 0];
    [x,fval] = fmincon(@(x) LLeval(x,y), x0, [], [], [], [], lb, [], [], options);
    %fprintf('negLik:%4g theta:%4g var:%4g \n', fval,x(1),x(2));
    hyp.theta = x(1);hyp.var = x(2);
    hyp.neighbor = floor(sqrt(-log(1e-4)/hyp.theta))+1;
    %logLik_grad_theta = - trace()
end

function neglogLik = LLeval(x,y)
    [numPatch, ~] = size(y);
    grid2Size = [sqrt(numPatch), sqrt(numPatch)];
    hyp.theta = x(1);hyp.var = x(2);
    hyp.neighbor = floor(sqrt(-log(1e-4)/hyp.theta))+1;
    Kernel = initGP_full(hyp ,grid2Size);
%     for posMiss = 1:numPatch
%         posNeighbor = neighborCal(grid2Size,posMiss,hyp.neighbor*2,sqrt(numPatch),neighborMap);
%         posTable2{posMiss} = posNeighbor; 
%     end
%     K = initGP_old(hyp,grid2Size,posTable2);
    L2 = sparse(choll(Kernel{2}));
    L1 = sparse(choll(Kernel{1}));
    y= reshape(y,size(L1,2),[]);
    % v = L'/y
    v = L2'\y/L1; 
    % reshape won't change trace trace()
    neglogLik =  sqrt(numPatch)*(log(det(Kernel{2}))+log(det(Kernel{1})))+trace(v'*v);
end
