function [x,y,z] = ind2sub3(siz,ndx)
    x = rem(ndx-1, siz(1)) + 1;
    temp = (ndx - x)/siz(1) + 1;
    y = rem(temp-1, siz(2)) + 1;
    z = (temp - y)/siz(2) + 1;
end