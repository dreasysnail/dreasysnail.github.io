function Kernel = initGP_full(hyp,grid)
Kernel = cell(2,1);
%thres = 1e-4*hyp.var;
for gid = 1:2
    for i = 1:grid(gid)
        for j = i:min(grid(gid),i+4*hyp.neighbor)
            temp = hyp.var * exp(-(j-i)^2*hyp.theta);
%             if temp < thres;
%                 continue;  
%             end
            Kernel{gid}(i,j) = temp;
            Kernel{gid}(j,i) = temp;
        end
    end
    %Kernel{gid} = sparse(Kernel{gid});
end
