function H2 = smoothCov(H,k)
    H = H' +0;
    for i = 1:size(H,1)
        H2(i,:) = conv(ones(1,k),H(i,:));
    end
    H2 = H2(:,floor(k/2):size(H,2)+floor(k/2)-1)';
    H2 = (H2/k>0.2)+0;