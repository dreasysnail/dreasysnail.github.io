function Kernel = initGP(hyp,grid)
Kernel = cell(2,1);
% thres = 1e-8*hyp.var;
for gid = 1:2
    idx = 1;
    xs = zeros(1,grid(gid)*(4*hyp.neighbor)); ys = xs; vals = xs; idx = idx + 1;
    for i = 1:grid(gid)
        xs(i) = i; ys(i) = i; vals(i) = hyp.var; 
        for j = i+1:min(grid(gid),i+hyp.neighbor)
            temp = hyp.var * exp(-(j-i)^2/hyp.theta);
%             if temp < thres;
%                 continue;  
%             end
            xs(idx:idx+1) = [i,j]; ys(idx:idx+1) = [j,i]; vals(idx:idx+1) = [temp,temp];
            idx = idx + 2;
        end
    end
    idx_nz = (xs~=0);
    xs = xs(idx_nz);ys = ys(idx_nz);vals = vals(idx_nz);
    % sparse approx
    Kernel{gid} = sparse(xs,ys,vals,grid(gid),grid(gid));
    Kernel{gid} = full(Kernel{gid});
end