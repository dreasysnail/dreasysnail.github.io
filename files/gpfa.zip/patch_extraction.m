function data = patch_extraction(images,patchSize,imageSize,numSample,isOverlap)
% 1 2
% 3 4
addpath('tool/');
if nargin < 4
    numSample = size(images,2);
end
if nargin < 5
    isOverlap = 'none';
end
if isOverlap == 'full'
    data = zeros(prod(patchSize),((imageSize(1)-patchSize(1)+1)*(imageSize(2)-patchSize(2)+1)),numSample);
    for i = 1:numSample
        data(:,:,i) = im2col(reshape(images(:,i),imageSize),patchSize,'sliding');
    end
elseif isOverlap == 'half'
    for i = 1:numSample
        data(:,:,i) = im2colstep(reshape(images(:,i),imageSize),patchSize,patchSize/2);
    end  
else
    data = zeros(prod(patchSize),prod(imageSize)/prod(patchSize),numSample);
    for i = 1:numSample
        I = reshape(images(:,i),imageSize(1),imageSize(2));
        for j1 = 1:imageSize(1)/patchSize(1)
            for j2 = 1:imageSize(2)/patchSize(2)
                patch = I((j1-1)*patchSize(1)+1:j1*patchSize(1),(j2-1)*patchSize(2)+1:j2*patchSize(2));
                data(:,j2+(j1-1)*imageSize(1)/patchSize(1),i) = reshape(patch,prod(patchSize),1);
            end
        end
    end
end
