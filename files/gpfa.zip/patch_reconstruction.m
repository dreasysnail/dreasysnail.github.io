function images = patch_reconstruction(recon, patchSize, imageSize, numSample, isOverlap)
% 1 2
% 3 4
if nargin < 4
    numSample = size(recon,2);
end
if nargin < 5
    isOverlap = 'none';
end
images = zeros(prod(imageSize),numSample);
if isOverlap == 'full'
    numPatch = numel(recon)/prod(patchSize)/numSample;
    for s = 1:numSample
        image = zeros(imageSize);
        Weight = zeros(imageSize);
        [rows,cols] = ind2sub(imageSize-patchSize+1,1:numPatch);
        for i=1:numPatch;
            thisPatch = recon(:,i+(s-1)*numPatch);
            Pos1  = rows(i)+(0:patchSize-1);
            Pos2 = cols(i)+(0:patchSize-1);
            image(Pos1,Pos2) = image(Pos1,Pos2) + reshape(thisPatch,patchSize);      
            Weight(Pos1,Pos2)= Weight(Pos1,Pos2) + 1;
        end
        images(:,s) = image(:)./Weight(:);
    end
elseif isOverlap == 'half'    
    numPatch = numel(recon)/prod(patchSize)/numSample;
    for s = 1:numSample
        image = zeros(imageSize);
        Weight = zeros(imageSize);
        [rows,cols] = ind2sub((imageSize-patchSize)./(patchSize/2)+1,1:numPatch);
        for i=1:numPatch;
            thisPatch = recon(:,i+(s-1)*numPatch);
            Pos1  = patchSize(1)/2*(rows(i)-1)+(1:patchSize);
            Pos2 = patchSize(2)/2*(cols(i)-1)+(1:patchSize);
            image(Pos1,Pos2) = image(Pos1,Pos2) + reshape(thisPatch,patchSize);      
            Weight(Pos1,Pos2)= Weight(Pos1,Pos2) + 1;
        end
        images(:,s) = image(:)./Weight(:);
    end
    
else
    recon = reshape(recon, prod(patchSize)*imageSize(2)/patchSize(2), []);
    count = 0;
    for i = 1:numSample
        temp = zeros(imageSize);
        for j = 1:imageSize(1)/patchSize(1)
            count = count + 1;
            temp((j-1)*patchSize(1)+1:j*patchSize(1),:) = reshape(recon(:,count),patchSize(1),[]);
        end
        images(:,i) = reshape(temp,[],1);
    end
end
