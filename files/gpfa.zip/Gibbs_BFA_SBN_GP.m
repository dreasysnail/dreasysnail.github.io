function history = Gibbs_BFA_SBN_GP(data,K,numBurnin,image,isMiss,missData,isLik,history)
close all;    addpath('mcmc');
[patchSize, numPatch, numSample] = size(data);
% set hyperparams , p denote precision,i.e. sigma^(-2)
% params: e0 f0  var   mean
g0 = 1e-6; h0 = 1e-6;
c0 = 1e-6; d0 = 1e-6;
e0 = 1e-6; f0 = 1e-6;

%sigma_p = 100/patchSize^2;

numCollection= 5;

% collapse patchSize,i,n -> patchSize, i*n 
isSVD = true;
isCPU = false;
isGPU = false;
isARD = false;

if isCPU; delete(gcp('nocreate')); if isempty((gcp('nocreate')));parpool(4);end; end;
% collapse patchSize,i,n -> patchSize, i*n 
if nargin < 7
    isLik = false;
    useHistory = false;
else
    useHistory = true;
end
if nargin < 5
    isMiss = false;
end
numTotal = numPatch* numSample;
dataZip = reshape(data,[patchSize,numTotal]);
% set initialization
if ~isSVD
    fprintf('use random initialization \n');
    D = normrnd(0,1,[patchSize K]);     % index patchSize,k
    WZip = randn(K,numTotal);
    ZZip = zeros(K,numTotal);
else
    fprintf('use SVD initialization \n');
    if isMiss
        [D,WZip,ZZip,~] = svdInit(dataZip,K,missData); 
    else
        [D,WZip,ZZip,~] = svdInit(dataZip,K);
    end
end
AllRecon = zeros(size(image,1)*size(image,2),numSample,numBurnin+numCollection);
imageSize = size(image);
%


%% SBN %%
numLayer = 1;
hiddenK(1) = max(floor(K/2),1); 
V = 1*randn(K,hiddenK(1));
%HZip = +(rand(hiddenK(1),numTotal)>rand(1,1));
HZip = (rand(hiddenK(1),numTotal) < 0.05);
if numLayer ~= 1
%     hiddenK(2) = hiddenK(1);
%     V2 = 0.1*randn(hiddenK(1),hiddenK(2));
%     H1Zip = zeros(hiddenK(2),numTotal);
%     b2 = -0.1*ones(hiddenK(2),1); 
end
b0 = -5*ones(K,1);
%b1 = -0*ones(hiddenK(1),1); 

%% GP %%
grid2Size = size(image)-[sqrt(patchSize)-1,sqrt(patchSize)-1];
%xg = {[1:grid2Size(1)]',[1:grid2Size(2)]'};               % construct a grid

%[~,ng] = covGrid('expand',xg);
%cov = {{@covSEiso},{@covSEiso}}; covg = {@covGrid,cov,xg};         % set up a GP
theta = linspace(1,1,hiddenK(1));
hyp = cell(1,hiddenK(1));


for k = 1:hiddenK(1)
%    hyp{k}.cov = [theta(k);0;theta(k);0]; hyp{k}.mean = [-20]; hyp{k}.lik = log(0.1);
     hyp{k}.theta = theta(k); hyp{k}.var = 0.7;hyp{k}.neighbor = floor(sqrt(-log(1e-6)*theta(k)))+1;
end
bmu = -2.6;
bsigma_p = 0.1;
b1 = bmu*ones(hiddenK(1),1);
%opt.cg_maxit = 100; opt.cg_tol = 5e-2;        % perform inference and prediction
%init
for k = 1:hiddenK(1)
    y{k} = 0*ones([numPatch,numSample]); gamma{k} = rand([numPatch,numSample]);
end
pos = (1:prod(grid2Size))';
neighborMap = reshape(pos,grid2Size);
%[posTable, ys2Cell, Ktemp, compress_idx] = Kernel_construction(hiddenK(1),neighborMap,hyp);
[posTable, ys2Cell, Ktemp, compress_idx] = Kernel_construction_new(hiddenK(1),neighborMap,hyp);
if useHistory
    D = history.D{end}(:,1:K);
    V = history.V{end}(1:K,1:hiddenK(1));
    b0 = history.b0{end}(1:K);
    tau_p = history.tau_p{end}; 
    phi_p = history.phi_p{end}; 
    sigma_p = history.sigma_p{end};
    if ~isLik
        WZip = history.WZip{end}(1:K,:);
        ZZip = history.ZZip{end}(1:K,:);
        HZip = history.HZip{end}(1:hiddenK(1),:);
    end
end

sigma_p =1;
for iter = 1:(numBurnin + numCollection)
    
    S = sparsify(WZip.*ZZip);
    % sample tau_p 
    tempC1 = c0 + K*numSample*numPatch/2;
    tempD1 = d0 + sum(sum(WZip.^2))/2; 
    tau_p = gamrnd(tempC1,1/tempD1);  
    % sample phi_p
    if isMiss
        tempE1 = e0 + nnz(missData)/2;
        tempF1 = f0 + sum(sum((dataZip - D * S).^2.*missData))/2;
    else
        tempE1 = e0 + patchSize*numSample*numPatch/2;
        tempF1 = f0 + sum(sum((dataZip - D * S).^2))/2;
    end
    phi_p = gamrnd(tempE1,1/tempF1);  
    % sample sigma_p
    tempG1 = g0 + K*patchSize/2;
    tempH1 = h0 + sum(sum(D.^2))/2;
    sigma_p = gamrnd(tempG1,1/tempH1);  

    % S = W.*Z
    % sample ZZip
    for k = 1:K
        S = sparsify(WZip.*ZZip);
        tempD = D;
        tempD(:,k) = zeros(patchSize,1);
        tempRes = dataZip - tempD * S;
        if isMiss
            tempRes = tempRes.*missData; 
            temp = D(:,k)'*(D(:,k)*(WZip(k,:).^2).*missData) - 2*D(:,k)'*tempRes.*WZip(k,:); 
        else
            temp = D(:,k)'*D(:,k)*(WZip(k,:).^2) - 2*D(:,k)'*tempRes.*WZip(k,:); 
        end
        % avoid numeric problem: log space
        tempP = exp(-temp*phi_p/2 + V(k,:)*HZip + b0(k));
        tempP = 1./(1+tempP);
        ZZip(k,:) = sparse(rand(1,numTotal) > tempP );
        %ZZip(k,:) = sparse(arrayfun(@(x) binornd(1,x),tempP));
        if any(any(isnan(ZZip)));  error('nan'); end
    end
    ZZip = sparsify(ZZip);
    

    % sample WZip
    %S = WZip.*ZZip;
    for k = 1:K
        % use sparsity in z to speed up calculation
         S = sparsify(WZip.*ZZip);
        idx1 = (ZZip(k,:) == 1);     % i*n
        if isMiss
            temp2Sigma_p = tau_p + (D(:,k)'*(bsxfun(@times,missData(:,idx1),D(:,k)))).*phi_p;  % 1*idx1
        else
            temp2Sigma_p = tau_p + (D(:,k)'*D(:,k))*phi_p;  %k,i*n
        end
        tempD = D;
        tempD(:,k) = zeros(patchSize,1);
        tempRes = dataZip(:,idx1) - tempD * S(:,idx1);
        if isMiss; tempRes = tempRes.*missData(:,idx1); end;
        temp2Mu = sum(bsxfun(@times,tempRes,D(:,k)),1)./temp2Sigma_p.*phi_p;
        temp2Sigma = sqrt(1./temp2Sigma_p);
        WZip(k,idx1) = temp2Mu + temp2Sigma.*randn(1,nnz(idx1));
        WZip(k,~idx1) = sqrt(1/tau_p)*randn(1,numTotal-nnz(idx1));
    end
        % sample d 
    if ~isLik
        S = sparsify(WZip.*ZZip);
        for k = 1:K
            if isMiss
                tempSigma_p = sigma_p + sum(bsxfun(@times,missData,S(k,:).^2),2).*phi_p;
            else
                tempSigma_p = sigma_p + sum(S(k,:).^2,2)*phi_p;
            end
            tempD = D;
            tempD(:,k) = zeros(patchSize,1);                
            tempRes = dataZip - tempD * S;
            if isMiss; tempRes = tempRes.*missData; end;
            tempMu = sum(bsxfun(@times,tempRes,S(k,:)),2)./tempSigma_p.*phi_p;
            tempSigma = sqrt(1./tempSigma_p);
            D(:,k) = tempMu + tempSigma.*randn(patchSize,1);
        end
    end
    
    
    %%%% sample SBN   %%%%
    sbnIteration = 5;
    if numLayer == 1
        if ~isLik
            [V,HZip,b0] = sbn_mcmc_single_layer_gp(ZZip,hiddenK(1),V,HZip,b0,y,b1,sbnIteration);
        else
            HZip = sbn_mcmc_single_layer_gp_lik(ZZip,hiddenK(1),V,HZip,b0,y,sbnIteration);
        end
    elseif numLayer == 2
        % fill in 
        [V,HZip,H1Zip,b0] = sbn_mcmc_2_layer_gp(ZZip,hiddenK(1),hiddenK(2), y, V,HZip,H1Zip,sbnIteration);
    else
        error('Wrong layer number \n'); exit;
    end
    
    
   
    
    %%%%% GP hidden %%%%
    if isGPU
		idx_c = hyp{k}.neighbor * (grid_rn + 1) + 1;  % the compressed element
        y = GP_GPU(K,y,b,ZZip,ys2Cell,Ktemp,posTable,compress_idx,idx_c,numPatch,numSample);
    else
	    for i = 1:numSample
	        for k = 1:hiddenK(numLayer)
	            h{k} = HZip(k,(i-1)*numPatch+1:i*numPatch);  %if numLayer == 1
                gamma{k}(:,i) = PolyaGamRndTruncated(ones(numPatch,1),y{k}(:,i)+b1(k),20);
            end
            if isCPU
                parfor k = 1:hiddenK(numLayer)
                    y{k}(:,i) = updateGP_mex(hyp{k}.neighbor,compress_idx{k}, posTable{k},y{k}(:,i),ys2Cell{k},Ktemp{k},gamma{k},0+full(h{k}),b1(k));
                end
            else
                for k = 1:hiddenK(numLayer)
                    y{k}(:,i) = updateGP_mex(hyp{k}.neighbor,compress_idx{k}, posTable{k},y{k}(:,i),ys2Cell{k},Ktemp{k},gamma{k},0+full(h{k}),b1(k));
%                     % sample y_k
%                     idx_next = 0;
%                     idx_c = hyp{k}.neighbor * (grid_rn + 1) + 1;  % the compressed element
%                     for posMiss = 1:numPatch 
%                         if compress_idx{k}(posMiss)
%                             idx_next = idx_next + 1;
%                             idx = idx_next;
%                         else
%                             idx = idx_c;
%                         end
%                         posTemp = posTable{k}{posMiss};
%                         ytemp = y{k}(posTemp,i);
%                         ys2 = ys2Cell{k}{idx};
%                         ymu = Ktemp{k}{idx}*(ytemp); 
%                         tempys2 = 1/(1/ys2 + gamma{k}(posMiss,i)) ;
%                         tempymu = (ymu/ys2 + h{k}(posMiss)-0.5-gamma{k}(posMiss,i)*b1(k)) * tempys2;
%                         y{k}(posMiss,i) = tempymu + sqrt(tempys2)*randn(1,1);
%                     end
                end
            end
	    end
	end
    % sample b
    for k = 1:hiddenK(numLayer)
        sigmaB = 1/(sum(sum(gamma{k}))+bsigma_p);
        muB = sigmaB.*(sum(HZip(k,:)-0.5-gamma{k}(:)'.*y{k}(:)',2) + bmu*bsigma_p);
        b1(k) = muB + sqrt(sigmaB)*randn(1,1);
    end
    %Automatic relevance determination
    if isARD
        for k = 1:hiddenK(numLayer)
            hyp{k} = ARD_gp(hyp{k},y{k}(:,1)); 
        end
        [posTable, ys2Cell, Ktemp, compress_idx] = Kernel_construction_new(hiddenK(1),neighborMap,hyp);
    end
    
    
    % display likelihood (left constant) and reconstruction error
    RMSE = sqrt(sum(sum((dataZip - D*S).^2)))/numSample;
    %display_network(D); drawnow;
    display_network(full([ZZip(:,1:numPatch)',HZip(:,1:numPatch)']));drawnow;
    %display_network(V(:));drawnow;
    %negLL = sum(sum((dataZip - D*S).^2))*phi_p/2 + norm(D(:))^2*sigma_p/2 + norm(WZip(:))^2*tau_p/2 ...
    %        -c0*log(tau_p) + d0*tau_p - e0*log(phi_p) + f0*phi_p;
     if ismatrix(image)

        PSNR = 0; negLL = 0; PSNR_avg = 0;
        if size(image,1)== size(image,2); image = image(:); end;
        for i = 1:numSample
            patch_idx = (i-1)*numPatch+1:i*numPatch;
            recon = D*(WZip(:,patch_idx).*ZZip(:,patch_idx)); 
            recon_rs = patch_reconstruction(recon, [sqrt(patchSize),sqrt(patchSize)], imageSize,1,'full');
            recon_rs = min(max(recon_rs,0),1);
			PSNR = PSNR + 20*log10(1/sqrt(mean((recon_rs-image(:)).^2)));
			
			% avg
			AllRecon(:,i,iter) = recon_rs; 	
			recon_rs_avg = mean(AllRecon(:,i,max((iter-numCollection),1):iter),3);
			recon_rs_avg = min(max(recon_rs_avg,0),1);
			PSNR_avg = PSNR_avg + 20*log10(1/sqrt(mean((recon_rs_avg(:)-image(:)).^2)));
            %recon_rs = reshape(recon_rs, imageSize);
            negLL = negLL + sum(sum((recon_rs-image(:)).^2))*phi_p/2;
        end
        PSNR = PSNR/numSample;
		PSNR_avg = PSNR_avg/numSample;
        negLL = negLL/numSample + (log(2*3.1415926)-log(phi_p))/2;
     else
        PSNR =0;
        negLL = sum(sum((dataZip - D*S).^2))*phi_p/2/numSample + (log(2*3.1415926)-log(phi_p))/2;
    end
    % debug 
    fprintf('Iter:%d     RMSE:%5g    negLL:%5g sparsity: %2g  PSNR %2g PSNR_avg %2g\n',iter,RMSE,negLL, nnz(ZZip)/numel(ZZip),PSNR, PSNR_avg);
    fprintf('phi:%2g\n',phi_p);
    % if iter > numBurnin
	if iter == numBurnin + numCollection
%         history.D{iter-numBurnin} = D;
%         history.V{iter-numBurnin} = V;
%         history.b0{iter-numBurnin} = b0;
%         history.b1{iter-numBurnin} = b1;
%         history.WZip{iter-numBurnin} = WZip;
%         history.ZZip{iter-numBurnin} = ZZip;
%         history.HZip{iter-numBurnin} = HZip;
%         history.tau_p{iter-numBurnin} = tau_p;
%         history.phi_p{iter-numBurnin} = phi_p;
%         history.sigma_p{iter-numBurnin} = sigma_p;
        history.hyp = hyp;
        history.bmu = bmu;
		history.recon = recon_rs_avg;
    end
    history.sparsity(iter) = nnz(ZZip)/numel(ZZip);
    history.RMSE(iter) = RMSE;
    history.negLL(iter) = negLL;
	history.PSRN(iter) = PSNR;
    history.PSRN_avg(iter) = PSNR_avg;
end
   
        
