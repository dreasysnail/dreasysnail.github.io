%GPUTEST

n = 1000;
a = randn(n);
c = gpuArray(randn(n));
a = a*a';
c = c*c';
tic;
a*a*a;
toc;
tic;
c*c*c;
toc;

tic;
for i=1:64
    a*a;
    randn(20)*randn(20);
end
toc;

parpool(4);
tic;
parfor i=1:64
    c*c;
    randn(20)*randn(20);
end
toc;

a = rand(2,1000,'gpuArray');
b= rand(1000,1);


tic; for i = 1:1000
%b= gpuArray(b);
a*b;
end; toc;