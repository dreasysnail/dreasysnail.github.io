function y = GP_GPU(K,y,b,ZZip,ys2Cell,Ktemp,posTable,compress_idx,idx_c,numPatch,numSample)

    h_g = gpuArray(permute(reshape(full(ZZip),[K,numPatch,numSample]),[3,1,2]));   % N K J
    y_g = gpuArray(permute(cat(3,y{:}),[2,3,1]));  % J N K -> N K J
    b_g = gpuArray(b);
    gamma_g = zeros(numSample,K,numPatch);
    for i = 1:numSample
        for k = 1:K
            gamma_g(i,k,:) = PolyaGamRndTruncated(ones(numPatch,1),y{k}(:,i)+b(k),20);
        end
    end
    gamma_g = gpuArray(gamma_g);
    parallel.gpu.rng(0, 'Philox4x32-10');
    idx_next = 0;
    for k = 1:K
        for posMiss = 1:numPatch 
            if compress_idx{k}(posMiss)
                idx_next = idx_next + 1;
                idx = idx_next;
            else
                idx = idx_c;
            end
            posTemp = posTable{k}{posMiss};
            ytemp = squeeze(y_g(:,k,posTemp));
            %ymu_g = bsxfun(@times,ytemp,Ktemp{k}{posMiss}');
            %ymu_g = sum(ymu_g,1);
            ymu_g = ytemp*Ktemp{k}{idx}';
            ys2 = ys2Cell{k}{idx};
            %tempys2_g = arrayfun(@(x) (1/(1/ys2 + x)), gamma_g(posMiss,k,:)) ;
            tempys2_g = 1./(1/ys2 + gamma_g(:,k,posMiss)) ;
            fun = @(ymu,h,gamma,tempys2,b,ys2) ((ymu/ys2 + h -0.5-gamma*b) * tempys2);
            tempymu_g = arrayfun(fun, ymu_g , h_g(:,k,posMiss), gamma_g(:,k,posMiss), tempys2_g,b_g(k), ys2);
            s=gpuArray.randn(numSample,1);
            y_g(:,k,posMiss) = arrayfun(@(x,y,s) (x+sqrt(y)*s), tempymu_g,tempys2_g,s);
        end
    end
    y_all = gather(y_g);
    for k = 1:K
        y{k} = squeeze(y_all(:,k,:))';
    end
    
     