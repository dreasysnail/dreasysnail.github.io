function [D,W,Z,Pi] = svdInit(X,K,missData)
    if size(X,3)==4
        X = reshape(X,size(X,1),[]);
    end    
    if nargin >2
        % use patch avg to fill in;
        patch_avg = sum(X,1)./((sum(missData,1))+1e-10);
        [~,miss_patch_idx] = find(~missData);
        X(~missData) = patch_avg(miss_patch_idx);
    end
    [P,N] = size(X);
    [U_1,S_1,V_1] = svd(full(X),'econ');
    if P<=K
        D = zeros(P,K);
        D(:,1:P) = U_1*S_1;
        W = zeros(N,K);
        W(:,1:P) = V_1;
    else
        D =  U_1*S_1;
        D = D(1:P,1:K);
        W = V_1;
        W = W(1:N,1:K);
    end
    temp = max(max(D));
    %temp = 1;
    D = D./temp;
    W = W'.*temp;
    %D(:,1) = zeros(P,1);
    Pi = 0.05*ones(K,1);
    %Z = sparse(rand(K,N)<repmat(Pi,1,N));
    Z = rand(K,N)<0.00;



    