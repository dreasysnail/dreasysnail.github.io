function [x,y] = ind2sub2(siz,ndx)
    x = rem(ndx-1, siz(1)) + 1;
    y = (ndx - x)/siz(1) + 1;
end