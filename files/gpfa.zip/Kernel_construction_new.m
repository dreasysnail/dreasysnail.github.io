function [posTable, ys2Cell, Ktemp, compress_idx] = Kernel_construction_new(K,neighborMap,hyp)
    posTable2 = cell(K,1);
    posTable = cell(K,1);
    Ktemp = cell(K,1);
    ys2Cell = cell(K,1);
    grid2Size = size(neighborMap);
    numPatch = prod(grid2Size);
    compress_idx = cell(K,1);
    %Transpose_ind = reshape(1:numPatch,grid2Size)'; Transpose_ind = Transpose_ind(:);
    for k = 1:K
        if k >=2&&hyp{k-1}.theta == hyp{k}.theta ;posTable{k} = posTable{k-1};posTable2{k} = posTable2{k-1};ys2Cell{k}=ys2Cell{k-1};Ktemp{k}=Ktemp{k-1};compress_idx{k}=compress_idx{k-1};continue;end
%         for posMiss = 1:numPatch
%             posNeighbor = neighborCal(grid2Size,posMiss,hyp{k}.neighbor,grid_rn,neighborMap);
%             posTable{k}{posMiss} = posNeighbor; 
%         end
        neighbor = hyp{k}.neighbor;
        % contain self
        for posMiss = 1:numPatch
            [posX1,posX2] = ind2sub2(grid2Size,posMiss);
            posTable2{k}{posMiss}{1} = (max(1,posX1-neighbor):min(posX1+neighbor,grid2Size(1)));
            posTable2{k}{posMiss}{2} = (max(1,posX2-neighbor):min(posX2+neighbor,grid2Size(2)));
            posNeighbor = neighborMap(posTable2{k}{posMiss}{1},posTable2{k}{posMiss}{2});
            posNeighbor = posNeighbor(:);
            posTable{k}{posMiss} = posNeighbor (posNeighbor ~= posMiss);
            
            center = true(grid2Size);
            center((1+hyp{k}.neighbor):(grid2Size(1)-hyp{k}.neighbor),(1+hyp{k}.neighbor):(grid2Size(2)-hyp{k}.neighbor)) = false;
            center((1+hyp{k}.neighbor),(1+hyp{k}.neighbor)) = true;
            compress_idx{k} = center(:); 
        end

%        Kernel = initGP_old(hyp{k},grid2Size,posTable2{k});
        %Kernel = initGP(hyp{k},grid2Size);
        Kernel = initGP_full(hyp{k},grid2Size);
%         for gid = 1:2
%             [Q{gid},Lambda{gid}] = eig(Kernel{gid});
%             %Q{gid} = inv(Q{gid});
%         end
        %Lambda_kron = kron(diag(Lambda{1}),diag(Lambda{2}));
        idx_c = 1;
        for posMiss = 1:numPatch
            if ~compress_idx{k}(posMiss);continue;end;
            xn2 = posTable2{k}{posMiss};
            % K_pos = Kernel(posMiss, 
            [posX1,posX2] = ind2sub2(grid2Size,posMiss);
            K_pos = kron(Kernel{2}(posX2,xn2{2}),Kernel{1}(posX1,xn2{1}));
            %K_pos(1) = 0;
            
            Ks = {Kernel{2}(xn2{2},xn2{2}),Kernel{1}(xn2{1},xn2{1})};
            idx = (posX2 - xn2{2}(1))*length(xn2{1}) + (posX1 - xn2{1}(1) + 1) ;
            %tic;for i = 1:100
            %[temp, ~] = conj_grad_solve2(Ks, idx, K_pos');
            %[temp, ~] = conj_grad_solve(Q, Lambda_kron, Transpose_ind(posMiss), K_pos');
            [temp, ~] = pre_conj_grad_solve2(Ks, idx, K_pos');
            %end;toc;
            temp = temp';temp(idx) = [];K_pos(idx) = [];
            % why??
            %posT = (posX1 - 1)*grid_rn + posX2 ;
            Ktemp{k}{idx_c} = temp;

            ys2Cell{k}{idx_c} = hyp{k}.var^2 - temp*K_pos';
                %error-free code Q&D
                %assert(ys2Cell{k}{posMiss}>=0);
            if ys2Cell{k}{idx_c} < 0
                warning('negative variance in GP');
                ys2Cell{k}{idx_c} = 1e-6;
            end
            idx_c = idx_c + 1;
         end
    end
    
    %% debugging
%     KK = kron(Kernel{1},Kernel{2});
% KK(1,1) = 1e10;
% ans2 = K_pos/KK;
%  LL =kron(Lambda{1},Lambda{2});
% LL = inv(LL);
% LL (1,1) = 0;LL (1,1) = 10e10;
%     KK2 = inv(kron(Q{1},Q{2}))'*LL*inv(kron(Q{2},Q{1}));
%     Q{1}*Lambda{1}*Q{1}';    inv(Q{1})'*Lambda{1}*inv(Q{1});
%     [x, residuals] = conj_grad_solve(Qs, V, noise, b);
%     [x, numofitr] = pre_conj_grad_solve(Qs, V, noise, input_data, input_index_to_N, C, numIter);
    
    