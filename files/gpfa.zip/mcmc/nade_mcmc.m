function [W,V,b,c,H,TrainAcc] = nade_mcmc(Vtrain, K, maxit, history, isLik)

%% Bayesian Inference for Sigmoid Belief Network via Gibbs Sampling
% By Zhe Gan (zhe.gan@duke.edu), Duke ECE, 9.1.2014
% V = sigmoid(W1*H1+b0), H1 = sigmoid(W2*H2+b1)  H2 = sigmoid(b2) 
% Input:
%       Vtrain: patchsize*ntrain training data
%       K:      numbers of latent hidden units
%       W:      K*P
%       V:      P*K
%       numBurnin,numCollection,space: parameters of Gibbs Sampling
% Output:
%       result: inferred matrix information
Vtrain = reshape(Vtrain,size(Vtrain,1),[]);
[P,ntrain] = size(Vtrain); 

%% initialize W and V
if nargin < 4
    fprintf('use random initialization \n');
    W = randn(K,P-1);
    V = randn(P,K);
    b = zeros(1,P);
    c = zeros(K,1);
    H = zeros(K,ntrain,P);
    isLik = false;
else
    W = history.W;
    V = history.V;
    b = history.b;
    c = history.c;
    H = history.H;
end
%b0 = 0.1*randn(K,1);
%prob = @(x) (1./(1+exp(-x)));
%H1train = +(repmat(prob(b1),1,ntrain) > rand(K1,ntrain));  
%H2train = +(repmat(prob(b2),1,ntrain) > rand(K2,ntrain));


% TPBN
e1 = 1; f1 = 1; 
e2 = 1; f2 = 1; 

% initialize gibbs sampler parameters
gamma0 = zeros(ntrain,P);
gamma1 = zeros(K,ntrain,P);

% for computational convenience 
%Vtrain = [zeros(P,1), Vtrain];
VtrainRecons = zeros(P,ntrain);
%% Gibbs sampling

for iter = 1:maxit
    % 1. update gamma
    for i = 1:P
        % gamma0
        Xvec = V(i,:)*H(:,:,i)+b(i); % 1*ntrain
        gamma0(:,i) = PolyaGamRndTruncated(ones(ntrain,1),Xvec',20); % truncated
        % gamma1
        if i == 1
            Xvec = repmat(c,ntrain,1);
        else
            Xmat = bsxfun(@plus,W(:,1:i-1)*Vtrain(1:i-1,:),c); % K*ntrain
            Xvec = reshape(Xmat,K*ntrain,1);
        end
        gamma1vec = PolyaGamRndTruncated(ones(K*ntrain,1),Xvec,20);
        gamma1(:,:,i) = reshape(gamma1vec,K,ntrain); 
    end 
    
    % 2. update W, V
    % update gammaW
    if ~isLik
        phiW = gamrnd(e1+0.5,1./(f1+0.5*W.*W)); 
        %phiW = 1e-3*ones(size(W));
        for j = 1:K
            convMat = zeros(P-1,P-1);
            for i = 1:P-1
                Hgam = bsxfun(@times,Vtrain(1:i,:),gamma1(j,:,i+1));  % align on ntrain
                convMat(1:i,1:i) = convMat(1:i,1:i) + Hgam*Vtrain(1:i,:)';
            end
            invSigmaW = diag(phiW(j,:)) + convMat;     % P*P
            tempMat = zeros(P-1,ntrain);
            for i = 1:P-1
                tempMat(1:i,:) = bsxfun(@plus,tempMat(1:i,:),(H(j,:,i+1)-0.5-c(j)*gamma1(j,:,i+1)));
            end
            MuW = invSigmaW\(sum(Vtrain(1:P-1,:).*tempMat,2)); % P*P * sum(P*ntrain,2) 
            R = choll(invSigmaW); 
            W(j,:) = (MuW + R\randn(P-1,1))';
        end
        % subplot(121);image(W); subplot(122);image(WCopy);


        % update V (P*K)
        phiV = gamrnd(e2+0.5,1./(f2+0.5*V.*V)); 
        %phiV = 1e-3*ones(size(V));
        for i = 1:P       
            Hgam = bsxfun(@times,H(:,:,i),gamma0(:,i)');
            invSigmaV = diag(phiV(i,:)) + Hgam*H(:,:,i)';
            MuV = invSigmaV\(sum(bsxfun(@times,H(:,:,i),Vtrain(i,:)-0.5-b(i)*gamma0(:,i)'),2));
            R = choll(invSigmaV); 
            V(i,:) = (MuV + R\randn(K,1))';
        end

        % subplot(121);image(V); subplot(122);image(VCopy);
    end

    % 3. update H
    for i = 1:P
        res = V(i,:)*H(:,:,i);  % 1* ntrain
        for j = 1:K
            res = res - V(i,j)*H(j,:,i);
            mat1 = bsxfun(@plus,res,b(i));
            vec1 = bsxfun(@times,Vtrain(i,:)-0.5-gamma0(:,i)'.*mat1,V(i,j)); % 1*n   be careful
            vec2 = bsxfun(@times,gamma0(:,i)',V(i,j).^2)/2; % 1*n
            if i == 1
                vec3 = c(j); 
            else
                vec3 = W(j,1:(i-1))*Vtrain(1:(i-1),:) + c(j);     % 1*n
            end
            logz = vec1 - vec2 + vec3; % 1*n
            probz = 1./(1+exp(-logz)); % 1*n
            H(j,:,i) = (probz>rand(1,ntrain));
            res = res + V(i,j)*H(j,:,i);
        end
    end
    %display_network([squeeze(H(:,1,:))',squeeze(HCopy(:,1,:))']);
    
    if ~isLik
        % 4. update b (P)
        for i = 1:P
            sigmaB = 1./(sum(gamma0(:,i))+1);  % 1*1
            muB = sigmaB.*sum(Vtrain(i,:)-0.5-gamma0(:,i)'.*(V(i,:)*H(:,:,i)),2);  
            b(i) = normrnd(muB,sqrt(sigmaB));
        end

        % 5. update c (K)

        sigmaC = 1./(sum(sum(gamma1,2),3)+1);  %K*1
        temp = H(:,:,1) - 0.5;
        for i = 1:P-1
            temp = temp + H(:,:,i+1) - 0.5 - W(:,1:i)*Vtrain(1:i,:).*gamma1(:,:,i+1);
        end    
        muC = sigmaC.*sum(temp,2);
        c = normrnd(muC,sqrt(sigmaC));
    end
    % 6. reconstruct the images
    for n = 1:ntrain
        X = sum(V.*squeeze(H(:,n,:))',2) + b'; % p*n
        prob = exp(X)./(1+exp(X));
        VtrainRecons(:,n) = (prob>rand(P,1));
    end
    TrainAcc(iter) = sum(sum(VtrainRecons==Vtrain))/P/ntrain;
   
    
    if mod(iter,1)==0
        disp(['Iteration: ' num2str(iter) ' Acc: ' num2str(TrainAcc(iter))]);
%        display_network([squeeze(H(:,1,:))',VtrainRecons]);
        %index = randperm(ntrain);
%         figure(222);
%         subplot(1,2,1); imagesc(W1); colorbar;
%         subplot(1,2,2); imagesc(H1train); colorbar;
%         figure(111);
%         display_network(VtrainRecons(:,1:100));
%         drawnow;
               %% plot hidden 
%         hiddenImg = zeros(K,K1);
%         for ii = 1:K1
%             for jj = 1:K
%                 hiddenImg(jj,ii) = W1(jj,ii)/sqrt(sum(W1(:,ii).^2));
%             end
%         end
%         display_network(hiddenImg);
    end
end



