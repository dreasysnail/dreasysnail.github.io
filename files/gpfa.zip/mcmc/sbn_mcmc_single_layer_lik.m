function [Htrain]= sbn_mcmc_single_layer_lik(Vtrain,K,W,Htrain,c,b,maxit)
%% Bayesian Inference for Sigmoid Belief Network via Gibbs Sampling
% By Zhe Gan (zhe.gan@duke.edu), Duke ECE, 9.1.2014
% V = sigmoid(W*H+c), H = sigmoid(b)
% Input:
%       Vtrain: p*ntrain training data
%       Vtest:  p*ntest  test     data
%       K:      number of latent hidden units
%       burnin,sp,space: parameters of Gibbs Sampling
% Output:
%       result: inferred matrix information

[p,ntrain] = size(Vtrain); 

%% initialize W and H
% b = 0.1*randn(K,1);
% prob = 1./(1+exp(-b));
% Htrain = +(repmat(prob,1,ntrain) > rand(K,ntrain));  
%e0 = 1; f0 = 0.8; 

%% Gibbs sampling
for iter = 1: maxit

    % 1. update gamma0
    Xmat = bsxfun(@plus,W*Htrain,c); % p*n
    Xvec = reshape(Xmat,p*ntrain,1);
    gamma0vec = PolyaGamRndTruncated(ones(p*ntrain,1),Xvec,20);
    gamma0Train = reshape(gamma0vec,p,ntrain);
    
    % 2. update W
%     for j = 1:p        
%         Hgam = bsxfun(@times,Htrain,gamma0Train(j,:));
%         invSigmaW = diag(phiW(j,:)) + Hgam*Htrain';
%         MuW = invSigmaW\(sum(bsxfun(@times,Htrain,Vtrain(j,:)-0.5-c(j)*gamma0Train(j,:)),2));
%         R = choll(invSigmaW); 
%         W(j,:) = (MuW + R\randn(K,1))';
%     end;
%     
    % update gammaW
%    phiW = gamrnd(e0+0.5,1./(f0+0.5*W.*W));

    % 3. update H
    res = W*Htrain;
    for k = 1:K
        res = res-W(:,k)*Htrain(k,:);
        mat1 = bsxfun(@plus,res,c);
        vec1 = sum(bsxfun(@times,Vtrain-0.5-gamma0Train.*mat1,W(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma0Train,W(:,k).^2))/2; % 1*n
        logz = vec1 - vec2 + b(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        Htrain(k,:) = (probz>rand(1,ntrain));
        res = res+W(:,k)*Htrain(k,:);
    end;
    
    % 4. update c
%     sigmaC = 1./(sum(gamma0Train,2)+1);
%     muC = sigmaC.*sum(Vtrain-0.5-gamma0Train.*(W*Htrain),2);
%     c = normrnd(muC,sqrt(sigmaC));

    % 5. update b
%     gamma1 = PolyaGamRndExact(ones(K,1),b);
%     sigmaB = 1./(ntrain*gamma1+1e0);
%     muB = sigmaB.*sum(Htrain-0.5,2);
%     b = normrnd(muB,sqrt(sigmaB));
    
%     % 6. reconstruct the images
%     X = bsxfun(@plus,W*Htrain,c); % p*n
%     prob = exp(X)./(1+exp(X));
%     VtrainRecons = (prob>rand(p,ntrain));

   
    
    
%     if mod(iter,1)==0
%         close all;
%         disp(['Iteration: ' num2str(iter) ' Acc: ' num2str(TrainAcc(iter)) ' ' num2str(TestAcc(iter))...
%             ' LogProb: ' num2str(TrainLogProb(iter))  ' ' num2str(TestLogProb(iter))...
%              ' Totally spend ' num2str(TotalTime(iter))]);
%         %index = randperm(ntrain);
%         figure(222);
%         subplot(1,2,1); imagesc(W); colorbar;
%         subplot(1,2,2); imagesc(Htrain); colorbar;
%         figure(111);
%         %dispims(VtrainRecons(:,index(1:100)),28,28);
%         display_network(VtrainRecons(:,1:100));
%         
%         %% plot hidden 
%         hiddenImg = zeros(p,K);
%         for ii = 1:K
%             for jj = 1:p
%                 hiddenImg(jj,ii) = W(jj,ii)/sqrt(sum(W(:,ii).^2));
%             end
%         end
%         display_network(hiddenImg);
%         drawnow;
%     end
end



