function result = sbn_mcmc_modified(Vtrain, Vtest, K1, K2)

%% Bayesian Inference for Sigmoid Belief Network via Gibbs Sampling
% By Zhe Gan (zhe.gan@duke.edu), Duke ECE, 9.1.2014
% modified by Yizhe Zhang to incorporate additional layer
% V = sigmoid(W1*H1+b0), H1 = sigmoid(W2*H2+b1)  H2 = sigmoid(b2) 
% Input:
%       Vtrain: K*ntrain training data
%       Vtest:  K*ntest  test     data
%       K1,K2:      numbers of latent hidden units
%       numBurnin,numCollection,space: parameters of Gibbs Sampling
% Output:
%       result: inferred matrix information


numBurnin= 100; space = 1; numCollection= 5;
[K,ntrain] = size(Vtrain); [~,ntest] = size(Vtest);

%% initialize W and H
b2 = 0.1*randn(K2,1); b1 = 0.1*randn(K1,1); b0 = 0.1*randn(K,1);
prob = @(x) (1./(1+exp(-x)));
H1train = +(repmat(prob(b1),1,ntrain) > rand(K1,ntrain));  
H2train = +(repmat(prob(b2),1,ntrain) > rand(K2,ntrain));  
H1test = +(repmat(prob(b1),1,ntest) > rand(K1,ntest)); 
H2test = +(repmat(prob(b2),1,ntest) > rand(K2,ntest)); 

% TPBN
e1 = 1.1; f1 = 0.01; phiW1 = ones(K,K1);
W1 = 0.1*randn(K,K1);
e2 = 1.1; f2 = 0.01; phiW2 = ones(K1,K2);
W2 = 0.1*randn(K1,K2);

% initialize gibbs sampler parameters
iter = 0;
maxit = numBurnin+ numCollection*space;
TrainAcc = zeros(1,maxit); TestAcc = zeros(1,maxit);
TotalTime = zeros(1,maxit);
TrainLogProb = zeros(1,maxit); 
TestLogProb = zeros(1,maxit);

result.W1 = zeros(K,K1);
result.W2 = zeros(K1,K2);
result.H1train = zeros(K1,ntrain);
result.H2train = zeros(K2,ntrain);
result.H1test = zeros(K1,ntest);
result.H2test = zeros(K2,ntest);
result.b2 = zeros(K2,1);
result.b1 = zeros(K1,1);
result.b0 = zeros(K,1);
result.Vtrain = zeros(K,ntrain);
result.Vtest = zeros(K,ntest);
result.gamma0Train = zeros(K,ntrain);
result.gamma0Test = zeros(K,ntest);
result.gamma1Train = zeros(K1,1);
result.gamma1Test = zeros(K1,1);
result.gamma2 = zeros(K2,1);

%% Gibbs sampling
tic;
while (iter < maxit)
    iter = iter + 1;

    % 1. update gamma0, gamma1
    Xmat = bsxfun(@plus,W1*H1train,b0); % K*n
    Xvec = reshape(Xmat,K*ntrain,1);
    gamma0vec = PolyaGamRndTruncated(ones(K*ntrain,1),Xvec,20);
    gamma0Train = reshape(gamma0vec,K,ntrain);
    
    Xmat = bsxfun(@plus,W1*H1test,b0); % K*n
    Xvec = reshape(Xmat,K*ntest,1);
    gamma0vec = PolyaGamRndTruncated(ones(K*ntest,1),Xvec,20);
    gamma0Test = reshape(gamma0vec,K,ntest);
    
    Xmat = bsxfun(@plus,W2*H2train,b1); % K1*n
    Xvec = reshape(Xmat,K1*ntrain,1);
    gamma1vec = PolyaGamRndTruncated(ones(K1*ntrain,1),Xvec,20);
    gamma1Train = reshape(gamma1vec,K1,ntrain);
    
    Xmat = bsxfun(@plus,W2*H2test,b1); % K1*n
    Xvec = reshape(Xmat,K1*ntest,1);
    gamma1vec = PolyaGamRndTruncated(ones(K1*ntest,1),Xvec,20);
    gamma1Test = reshape(gamma1vec,K1,ntest);
    
    
    % 2. update W1, W2
    for j = 1:K        
        Hgam = bsxfun(@times,H1train,gamma0Train(j,:));
        invSigmaW = diag(phiW1(j,:)) + Hgam*H1train';
        MuW = invSigmaW\(sum(bsxfun(@times,H1train,Vtrain(j,:)-0.5-b0(j)*gamma0Train(j,:)),2));
        R = choll(invSigmaW); 
        W1(j,:) = (MuW + R\randn(K1,1))';
    end;
    
    for j = 1:K1        
        Hgam = bsxfun(@times,H2train,gamma1Train(j,:));
        invSigmaW = diag(phiW2(j,:)) + Hgam*H2train';
        MuW = invSigmaW\(sum(bsxfun(@times,H2train,Vtrain(j,:)-0.5-b1(j)*gamma1Train(j,:)),2));
        R = choll(invSigmaW); 
        W2(j,:) = (MuW + R\randn(K2,1))';
    end;
    
    % update gammaW
    phiW1 = gamrnd(e1+0.5,1./(f1+0.5*W1.*W1));
    phiW2 = gamrnd(e2+0.5,1./(f2+0.5*W2.*W2)); 
    

    % 3. update H1, H2
    res = W1*H1train;
    for k = 1:K1
        res = res-W1(:,k)*H1train(k,:);
        mat1 = bsxfun(@plus,res,b0);
        vec1 = sum(bsxfun(@times,Vtrain-0.5-gamma0Train.*mat1,W1(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma0Train,W1(:,k).^2))/2; % 1*n
        vec3 = W2(k,:)*H2train;     % 1*n
        logz = vec1 - vec2 + vec3 + b1(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H1train(k,:) = (probz>rand(1,ntrain));
        res = res+W1(:,k)*H1train(k,:);
    end;
    res = W2*H2train;
    for k = 1:K2
        res = res-W2(:,k)*H2train(k,:);
        mat2 = bsxfun(@plus,res,b1);
        vec1 = sum(bsxfun(@times,H1train-0.5-gamma1Train.*mat2,W2(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma1Train,W2(:,k).^2))/2; % 1*n
        logz = vec1 - vec2 + b2(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H2train(k,:) = (probz>rand(1,ntrain));
        res = res+W2(:,k)*H2train(k,:);
    end;
    
    
    res = W1*H1test;
    for k = 1:K1
        res = res-W1(:,k)*H1test(k,:);
        mat1 = bsxfun(@plus,res,b0);
        vec1 = sum(bsxfun(@times,Vtest-0.5-gamma0Test.*mat1,W1(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma0Test,W1(:,k).^2))/2; % 1*n
        vec3 = W2(k,:)*H2test;     % 1*n
        logz = vec1 - vec2 + vec3 + b1(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H1test(k,:) = (probz>rand(1,ntest));
        res = res+W1(:,k)*H1test(k,:);
    end;
    res = W2*H2test;
    for k = 1:K2
        res = res-W2(:,k)*H2test(k,:);
        mat2 = bsxfun(@plus,res,b1);
        vec1 = sum(bsxfun(@times,H1test-0.5-gamma1Test.*mat2,W2(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma1Test,W2(:,k).^2))/2; % 1*n
        logz = vec1 - vec2 + b2(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H2test(k,:) = (probz>rand(1,ntest));
        res = res+W2(:,k)*H2test(k,:);
    end;
    
    
    % 4. update b0
    sigmaB0 = 1./(sum(gamma0Train,2)+1);
    muB0 = sigmaB0.*sum(Vtrain-0.5-gamma0Train.*(W1*H1train),2);
    b0 = normrnd(muB0,sqrt(sigmaB0));
    
    sigmaB1 = 1./(sum(gamma1Train,2)+1);
    muB1 = sigmaB1.*sum(H1train-0.5-gamma1Train.*(W2*H2train),2);
    b1 = normrnd(muB1,sqrt(sigmaB1));

    % 5. update b1
    gamma2 = PolyaGamRndExact(ones(K2,1),b2);
    sigmaB2 = 1./(ntrain*gamma2+1e0);
    muB2 = sigmaB2.*sum(H2train-0.5,2);
    b2 = normrnd(muB2,sqrt(sigmaB2));
    
    % 6. reconstruct the images
    X = bsxfun(@plus,W2*H2train,b1); % K*n
    prob = exp(X)./(1+exp(X));
    H1trainRecons = (prob>rand(K1,ntrain));
    X = bsxfun(@plus,W1*H1trainRecons,b0); % K*n
    prob = exp(X)./(1+exp(X));
    VtrainRecons = (prob>rand(K,ntrain));
    
    
    X = bsxfun(@plus,W2*H2test,b1); % K*n
    prob = exp(X)./(1+exp(X));
    H1testRecons = (prob>rand(K1,ntest));
    X = bsxfun(@plus,W1*H1testRecons,b0); % K*n
    prob = exp(X)./(1+exp(X));
    VtestRecons = (prob>rand(K,ntest));
    
    % 7. Save samples.
    ndx = iter - numBurnin;
    test = mod(ndx,space);  
    if (ndx>0) && (test==0)
        result.W1 = result.W1 + W1/numCollection;
        result.W2 = result.W2 + W2/numCollection;
        result.H1train = result.H1train + H1train/numCollection;
        result.H2train = result.H2train + H2train/numCollection;
        result.H1test = result.H1test + H1test/numCollection;
        result.H2test = result.H2test + H2test/numCollection;
        result.b0 = result.b0 + b0/numCollection;
        result.b1 = result.b1 + b1/numCollection;
        result.b2 = result.b2 + b2/numCollection;
        result.Vtrain = result.Vtrain + VtrainRecons/numCollection;
        result.Vtest = result.Vtest + VtestRecons/numCollection;
        result.gamma0Train = result.gamma0Train + gamma0Train/numCollection;
        result.gamma0Test = result.gamma0Test + gamma0Test/numCollection;
        result.gamma1Train = result.gamma1Train + gamma1Train/numCollection;
        result.gamma1Test = result.gamma1Test + gamma1Test/numCollection;
        result.gamma2 = result.gamma2 + gamma2/numCollection;
    end;
    
    TrainAcc(iter) = sum(sum(VtrainRecons==Vtrain))/K/ntrain;
    TestAcc(iter) = sum(sum(VtestRecons==Vtest))/K/ntest;
    % Note that, this is just the likelihood, not the marginal likelihood.
    % log prob. of training data
    mat = bsxfun(@plus,W1*H1trainRecons ,b0);
    TrainLogProb(iter) = sum(sum(mat.*Vtrain-log(1+exp(mat))))/ntrain;
    % log prob. of test data
    mat = bsxfun(@plus,W1*H1testRecons ,b0);
    TestLogProb(iter) = sum(sum(mat.*Vtest-log(1+exp(mat))))/ntest; 
    TotalTime(iter) = toc;
    if mod(iter,1)==0
        disp(['Iteration: ' num2str(iter) ' Acc: ' num2str(TrainAcc(iter)) ' ' num2str(TestAcc(iter))...
            ' LogProb: ' num2str(TrainLogProb(iter))  ' ' num2str(TestLogProb(iter))...
             ' Totally spend ' num2str(TotalTime(iter))]);
        %index = randperm(ntrain);
%         figure(222);
%         subplot(1,2,1); imagesc(W1); colorbar;
%         subplot(1,2,2); imagesc(H1train); colorbar;
%         figure(111);
%         display_network(VtrainRecons(:,1:100));
%         drawnow;
               %% plot hidden 
        hiddenImg = zeros(K,K1);
        for ii = 1:K1
            for jj = 1:K
                hiddenImg(jj,ii) = W1(jj,ii)/sqrt(sum(W1(:,ii).^2));
            end
        end
        display_network(hiddenImg);
    end
end;
result.TrainAcc = TrainAcc; 
result.TestAcc = TestAcc;
result.TotalTime = TotalTime;
result.TrainLogProb = TrainLogProb; 
result.TestLogProb = TestLogProb;


