%function nade_generate()
P = 28*28;
ntrain = 100;
K = 10;
W = 10*randn(K,P-1);
V = 10*randn(P,K);
H = zeros(K,ntrain,P);
b = randn(1,P);
c = randn(K,1);
%b = zeros(1,P);c = zeros(K,1);
Vtrain = zeros(P,ntrain);
sigmoid = @(x) (1./(1+exp(-x)));
e1 = 1;
f1 = 1;
e2 = 1;
f2 = 1;

for n = 1:ntrain
    % H1
    H(:,n,1) = (sigmoid(c) > rand(K,1));
    Vtrain(1,n) = (sigmoid(V(1,:)*H(:,n,1) + b(1)) > rand(1,1));
    for i = 2:P
        H(:,n,i) = (sigmoid(W(:,1:(i-1))*Vtrain(1:(i-1),n)+c) > rand(K,1));
        Vtrain(i,n) = (sigmoid(V(i,:)*H(:,n,i) + b(i)) > rand(1,1));
    end
end
display_network(Vtrain);
maxit =100;
[nade.W,nade.V,nade.b,nade.c,nade.H,nade.Acc] = nade_mcmc(Vtrain,K,maxit); 
isLik=true;
[nade.W,nade.V,nade.b,nade.c,nade.H,nade.Acc] = nade_mcmc(Vtest,K,maxit,nade,isLik); 
