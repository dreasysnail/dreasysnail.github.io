function [W1,W2,H1train,H2train,b0,b1,b2] = sbn_mcmc_2_layer(Vtrain, K1, K2, W1,W2, H1train,H2train,b0,b1,b2, maxit)

%% Bayesian Inference for Sigmoid Belief Network via Gibbs Sampling
% By Zhe Gan (zhe.gan@duke.edu), Duke ECE, 9.1.2014
% modified by Yizhe Zhang to incorporate additional layer
% V = sigmoid(W1*H1+b0), H1 = sigmoid(W2*H2+b1)  H2 = sigmoid(b2) 
% Input:
%       Vtrain: K*ntrain training data
%       Vtest:  K*ntest  test     data
%       K1,K2:      numbers of latent hidden units
%       numBurnin,numCollection,space: parameters of Gibbs Sampling
% Output:
%       result: inferred matrix information

[K,ntrain] = size(Vtrain); 

%% initialize W and H
%b2 = 0.1*randn(K2,1); b1 = 0.1*randn(K1,1);
%b0 = 0.1*randn(K,1);
%prob = @(x) (1./(1+exp(-x)));
%H1train = +(repmat(prob(b1),1,ntrain) > rand(K1,ntrain));  
%H2train = +(repmat(prob(b2),1,ntrain) > rand(K2,ntrain));  

% TPBN
e1 = 1; f1 = 1; phiW1 = ones(K,K1);
%W1 = 0.1*randn(K,K1);
e2 = 1; f2 = 1; phiW2 = ones(K1,K2);
%W2 = 0.1*randn(K1,K2);

% initialize gibbs sampler parameters


%% Gibbs sampling

for iter = 1:maxit
    % 1. update gamma0, gamma1
    Xmat = bsxfun(@plus,W1*H1train,b0); % K*n
    Xvec = reshape(Xmat,K*ntrain,1);
    gamma0vec = PolyaGamRndTruncated(ones(K*ntrain,1),Xvec,20);
    gamma0Train = reshape(gamma0vec,K,ntrain);
    
    Xmat = bsxfun(@plus,W2*H2train,b1); % K1*n
    Xvec = reshape(Xmat,K1*ntrain,1);
    gamma1vec = PolyaGamRndTruncated(ones(K1*ntrain,1),Xvec,20);
    gamma1Train = reshape(gamma1vec,K1,ntrain);
    
    
    
    % 2. update W1, W2
        % update gammaW
    phiW1 = gamrnd(e1+0.5,1./(f1+0.5*W1.*W1));
    phiW2 = gamrnd(e2+0.5,1./(f2+0.5*W2.*W2)); 
    for j = 1:K        
        Hgam = bsxfun(@times,H1train,gamma0Train(j,:));
        invSigmaW = diag(phiW1(j,:)) + Hgam*H1train';
        MuW = invSigmaW\(sum(bsxfun(@times,H1train,Vtrain(j,:)-0.5-b0(j)*gamma0Train(j,:)),2));
        R = choll(invSigmaW); 
        W1(j,:) = (MuW + R\randn(K1,1))';
    end;
    
    for j = 1:K1        
        Hgam = bsxfun(@times,H2train,gamma1Train(j,:));
        invSigmaW = diag(phiW2(j,:)) + Hgam*H2train';
        MuW = invSigmaW\(sum(bsxfun(@times,H2train,Vtrain(j,:)-0.5-b1(j)*gamma1Train(j,:)),2));
        R = choll(invSigmaW); 
        W2(j,:) = (MuW + R\randn(K2,1))';
    end;
    

    

    % 3. update H1, H2
    res = W1*H1train;
    for k = 1:K1
        res = res-W1(:,k)*H1train(k,:);
        mat1 = bsxfun(@plus,res,b0);
        vec1 = sum(bsxfun(@times,Vtrain-0.5-gamma0Train.*mat1,W1(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma0Train,W1(:,k).^2))/2; % 1*n
        vec3 = W2(k,:)*H2train;     % 1*n
        logz = vec1 - vec2 + vec3 + b1(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H1train(k,:) = (probz>rand(1,ntrain));
        res = res+W1(:,k)*H1train(k,:);
    end;
    res = W2*H2train;
    for k = 1:K2
        res = res-W2(:,k)*H2train(k,:);
        mat2 = bsxfun(@plus,res,b1);
        vec1 = sum(bsxfun(@times,H1train-0.5-gamma1Train.*mat2,W2(:,k))); % 1*n
        vec2 = sum(bsxfun(@times,gamma1Train,W2(:,k).^2))/2; % 1*n
        logz = vec1 - vec2 + b2(k); % 1*n
        probz = 1./(1+exp(-logz)); % 1*n
        H2train(k,:) = (probz>rand(1,ntrain));
        res = res+W2(:,k)*H2train(k,:);
    end;
    
    
    % 4. update b0
    sigmaB0 = 1./(sum(gamma0Train,2)+1);
    muB0 = sigmaB0.*sum(Vtrain-0.5-gamma0Train.*(W1*H1train),2);
    b0 = normrnd(muB0,sqrt(sigmaB0));
    
    sigmaB1 = 1./(sum(gamma1Train,2)+1);
    muB1 = sigmaB1.*sum(H1train-0.5-gamma1Train.*(W2*H2train),2);
    b1 = normrnd(muB1,sqrt(sigmaB1));

    % 5. update b1
    gamma2 = PolyaGamRndExact(ones(K2,1),b2);
    sigmaB2 = 1./(ntrain*gamma2+1e0);
    muB2 = sigmaB2.*sum(H2train-0.5,2);
    b2 = normrnd(muB2,sqrt(sigmaB2));
    

    
    
   
    
%     if mod(iter,1)==0
%         disp(['Iteration: ' num2str(iter) ' Acc: ' num2str(TrainAcc(iter)) ' ' num2str(TestAcc(iter))...
%             ' LogProb: ' num2str(TrainLogProb(iter))  ' ' num2str(TestLogProb(iter))...
%              ' Totally spend ' num2str(TotalTime(iter))]);
%         %index = randperm(ntrain);
% %         figure(222);
% %         subplot(1,2,1); imagesc(W1); colorbar;
% %         subplot(1,2,2); imagesc(H1train); colorbar;
% %         figure(111);
% %         display_network(VtrainRecons(:,1:100));
% %         drawnow;
%                %% plot hidden 
%         hiddenImg = zeros(K,K1);
%         for ii = 1:K1
%             for jj = 1:K
%                 hiddenImg(jj,ii) = W1(jj,ii)/sqrt(sum(W1(:,ii).^2));
%             end
%         end
%         display_network(hiddenImg);
%     end
end



