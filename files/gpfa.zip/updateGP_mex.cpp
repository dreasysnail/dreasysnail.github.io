/*==========================================================
 * updateGP_mex.cpp
 *
 *
 * The calling syntax is:
 *
 *		y = updateGP_mex(neighbor,compress_idx,posTable,y,ys2cell,Ktemp,gamma,h,b);
 *
 * This is a MEX-file for MATLAB.
 *
 *========================================================*/
// make: mex -PATCHArrayDims 
//
#include "mex.h"
#include <random>
//#include <vector>
#include <math.h>
#include "matrix.h"
//#include "Eigen/Dense"
#include <numeric>
// PATCH　than numPatch
#define PATCH 260000
#define NEIGHBOR 200
#define PATCHCOMP 9000
//using namespace Eigen;
using namespace std;
// random stuff
std::mt19937 Engine;
std::normal_distribution<double> randn( 0, 1);

//
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	mwIndex posMiss;
	
	// set seed
	if( nrhs == 1 ){
		Engine.seed( (int) mxGetScalar( prhs[0] ) );
		// randu.reset( (int) mxGetScalar( prhs[0] ) );
		return;
	}
/* 	if( !mxIsDouble(prhs[0])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","seq must be a int vector.");
    }
    if( !mxIsDouble(prhs[1])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","tr must be a double matrix.");
    }
    if( !mxIsDouble(prhs[2])) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","e must be a double matrix.");
    }
    if( !mxIsDouble(prhs[3])||
        mxGetNumberOfElements(prhs[3])!=1) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","k must be a scalar.");
    } */
    
    
    
    /* get the value of the scalar input  */
    //be careful
    unsigned char neighbor = (unsigned char)mxGetScalar(prhs[0]);
	// logical
	mxLogical *compress_idx = mxGetLogicals( prhs[1] );
	mwSize numPatch = mxGetM( prhs[3] );
	mwSize numPatch_comp = mxGetN(prhs[4]);
	double *posTable[PATCH] = {NULL};
	//mexPrintf("%lf\t",posTable[0][0]);
	mwSize posTable_size[PATCH];
	for (int tempIdx = 0;tempIdx < numPatch; tempIdx++){
		posTable[tempIdx] = mxGetPr(mxGetCell( prhs[2], tempIdx ));
		posTable_size[tempIdx] = mxGetM(mxGetCell(prhs[2], tempIdx));
	}
	//mwSize numSample = mxGetN( prhs[3] );
	//Map<MatrixXd> y( mxGetPr( prhs[3] ), numPatch, numSample );
	double *y = mxGetPr(prhs[3]);
	
	double ys2cell[PATCH] = {0};
	for (int tempIdx = 0;tempIdx < numPatch_comp; tempIdx++){
		ys2cell[tempIdx] = mxGetPr(mxGetCell( prhs[4], tempIdx ))[0];
	}
	
	//double *ys2cell = mxGetPr(prhs[4]);
	double *Ktemp[PATCHCOMP] = {NULL};
	for (int tempIdx = 0;tempIdx < numPatch_comp; tempIdx++){
		Ktemp[tempIdx] = mxGetPr(mxGetCell( prhs[5], tempIdx ));
	}
	//Map<MatrixXd> gamma( mxGetPr( prhs[6] ), numPatch, numSample );
	double *gamma = mxGetPr(prhs[6]);
	double *h = mxGetPr(prhs[7]);
	double b = (double)mxGetScalar(prhs[8]);
	
	int idx_next = -1;
	int idx_c = neighbor * (int)(sqrt((double)numPatch) + 1);
	int idx = 0;
//	vector<double> ytemp;
	double ys2;
	double ymu = 0;
	double tempys2, tempymu;	
	for (mwIndex posMiss = 0; posMiss < numPatch; posMiss++){
		if (compress_idx[posMiss]){
			idx_next = idx_next + 1;
			idx = idx_next;
		} else{
			idx = idx_c;
		}
		double* thisPosTable = posTable[posMiss];
		// vector<double> posTemp(thisPosTable,thisPosTable + );
		for (int tempIdx = 0; tempIdx < posTable_size[posMiss]; tempIdx++){
//			ytemp.push_back(y[thisPosTable[tempIdx]]);
			ymu += (double)y[int(thisPosTable[tempIdx])-1]*Ktemp[idx][tempIdx];
		}
		ys2 = ys2cell[idx];
		tempys2 = 1/(1/ys2 + gamma[posMiss]);
		tempymu = (ymu/ys2 + h[posMiss] -0.5 - gamma[posMiss]*b) * tempys2;
		y[posMiss] = tempymu + sqrt(tempys2)*randn(Engine);
		ymu = 0;
		
	}
	plhs[0] = mxCreateDoubleMatrix( numPatch, 1, mxREAL );
	double *p1 = mxGetPr(plhs[0]);
	for (int tempIdx = 0;tempIdx < numPatch; tempIdx++){
		p1[tempIdx] = y[tempIdx];
	}
	
	

	
}