function alpha = kron_mvprod(A,B,y,isTranspose)
% find alpha = A kron B * y
% istranspose A,B AT BT
%     if nargin < 4
%         isTranspose = false;
%     end 
    if ~isTranspose
        y= reshape(y,size(B,2),[]);
        alpha = B*y*A';
    else
        y= reshape(y,size(B,1),[]);
        alpha = B'*y*A;
    end
    alpha = alpha(:);
