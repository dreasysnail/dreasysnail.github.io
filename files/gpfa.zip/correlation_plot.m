%load('C:\Users\Yizhe\Desktop\temp\pepper0.1_denoise_sbn.mat')
[Vmax,idx] = sort(V,1);
%imagesc(image)
im = 9;
tempD = reshape(D,64,[]);
for hidd_i = 1:64
    %neg 
    subplot(121);
    display_network(tempD(:,idx(1:im,hidd_i)));
    %pos
    subplot(122);
    display_network(tempD(:,idx(end-im:end-1,hidd_i)));
    title(num2str(hidd_i));
    print(['C:\Users\Yizhe\Desktop\temp\' num2str(hidd_i)],'-dpng')
end