function Kernel = initGP_full_3D(hyp,grid,m)
Kernel = cell(2,1);
%thres = 1e-4*hyp.var;
for gid = 1:2
    for i = 1:grid(gid)
        for j = i:min(grid(gid),i+4*hyp.neighbor)
            temp = hyp.var * exp(-(j-i)^2*hyp.theta);
%             if temp < thres;
%                 continue;  
%             end
            Kernel{gid}(i,j) = temp;
            Kernel{gid}(j,i) = temp;
        end
    end
    %Kernel{gid} = sparse(Kernel{gid});
end

%
% grid 3 rgb-d
gid = 3;
for i = 1:grid(gid)
    for j = i:grid(gid)
        temp = hyp.var * exp(-channel_dist(i,j,hyp.m)^2*hyp.theta);
%             if temp < thres;
%                 continue;  
%             end
        Kernel{gid}(i,j) = temp;
        Kernel{gid}(j,i) = temp;
    end
end
end


function dist = channel_dist(i,j,m)
    %theta_d = 1;
    theta_d = 1; m = 2;
    if i==j
        dist = 0;
        return
    end
    if i<=3 && j<=3 
        dist = theta_d;    
    elseif i>3||j>3
        dist = m;
    else
        error('error');
    end
end
        