load('meta_donorB.mat');
numBurnin = 900; K = 50;
[mp, pp,pm,history] = evaluation(data,K,numBurnin);

[~,topword.toptopicid] = sort(history.var{end}.rk,'descend');

[topword.prop,topword.id] = sort(history.var{end}.Psi(:,topword.toptopicid),1,'descend');

topword.word = words(topword.id);

for i = 1:K
    topword.top{i} = strjoin(topword.word(1:5,i)');
end

[toptop.prop,toptop.id] = sort(history.var{end}.Phi(:,topword.toptopicid),1,'descend');

toptop.top = topword.top(toptop.id);

for topId = 1:40
    meanTheta = 0; meanPZZip = 0;
    
%     for i = 1:numCollection
%         meanTheta = meanTheta + history.var{i}.theta(topword.toptopicid(topId),:);
%     end
%     plot(linspace(1790,2014,length(meanTheta)),meanTheta/numCollection); 

    for i = 1:numCollection
        meanPZZip = meanPZZip + history.var{i}.pZZip(topword.toptopicid(topId),:);
    end    
    plot(linspace(1987,2003,length(meanPZZip)),meanPZZip/numCollection); 
    title( topword.top{topword.toptopicid(topId)}); xlim([1987 2003]);xlabel('Time ordered document','FontSize',16);ylabel('Topic probability','FontSize',16);
    print(['figs/topic_STU',num2str(topId)],'-djpeg','-r300');
end
clustergram(history.var{end}.theta(topword.toptopicid,:),'RowLabels',[],'cluster','column','Colormap','gray');
