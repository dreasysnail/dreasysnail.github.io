function [ZZip, z0, pZZip] = sample_Z(x_kn , p0, rk, Phi,W, sk, p1,C_k1n, Pi_k, numSample,y_kn)
    numTime = size(x_kn,2)/numSample;
    K = size(x_kn,1);
    % shift 1 step backward, rm first  zi-1 -> ci 
    t1_ix = 1:numTime:numSample*numTime;
    c0 = C_k1n(:,t1_ix);
    C_k1n = [C_k1n(:,2:end),zeros(K,1)];
    tn_ix = numTime:numTime:numSample*numTime;
    C_k1n(:,tn_ix) = zeros(K,numSample);

    lix = (x_kn == 0 & C_k1n == 0 & y_kn == 0);
    % rix index k
    [rix, cix] = find( x_kn == 0 & C_k1n == 0 & y_kn == 0);
    % calculate Pi
    BPL = @(lambda) (1 - exp(-lambda));
    % be careful
    lambda = Phi * W;
    Pi = BPL(lambda);
%     Pi = [zeros(K,1), Pi(:,1:end-1)];
%     t1_ix = 1:numTime:numSample*numTime;
%     Pi(:,t1_ix) = repmat(Pi_k,1,numSample);
    
    % t= 1:numTime-1 
    %p1 = Pi(rix).*( ( 1 - this.pn(cix)'  ).^this.rk(rix) );
    p_1 = Pi(lix).*( ( 1 - p0 ).^rk(rix) ).*( ( 1 - p1 ).^sk(rix) );   
    % correct for time T
    idx = find(ismember(cix,tn_ix));
    % need test
    p_1(idx) = p_1(idx)./( ( 1 - p1).^sk(rix(idx))) ;  
    
    p_0 = 1 - Pi(lix);

    ZZip = ones(size(x_kn));
    ZZip(lix) =  (p_1./( p_1 + p_0 ) ) > rand( size( rix )) ;
    pZZip = ones(size(x_kn));
    pZZip(lix) = (p_1./( p_1 + p_0 ) ) ;
    %ss = (p_1./( p_1 + p_0 ) );
    %update z0
    lix = (c0 == 0);
    % rix index k
    [rix, cix] = find( c0 == 0);
    p_1 = Pi_k(rix).*( ( 1 - p1 ).^sk(rix) );
    p_0 = 1 - Pi(rix);
    z0 = ones(size(c0));
    z0(lix) =  (p_1./( p_1 + p_0 ) ) > rand( size( rix )) ;
    pZ0 = ones(size(c0));
    pZ0(lix) = (p_1./( p_1 + p_0 ) ) ;
    pZZip = [pZ0, pZZip];
    ZZip = sparse(ZZip);
    z0 = sparse(z0);
    
    %imagesc(ZZip);drawnow;
    
    




