function history = gibbs_PFA(data,K,numBurnin,isLik,history_old)
close all; addpath('tools');

% preprocess
if nargin < 4
    isLik = false;  
end
if nargin < 5
    useHistory = false;
end


% preprocess
if ismatrix(data)
    numSample = 1;
    [P, numTime] = size(data);
else
    [P, numTime, numSample ] = size(data);
end

numTotal = numTime * numSample;
% options

numCollection= 1;

% hypers

hyp = 3e-1;
alpha_psi = hyp;
p0 = 0.5;
rk_a = hyp;
rk_b = 1/hyp;

% alpha_phi = 0.3;
% p1 = 0.5;
% sk_a = 1.2;
% sk_b = 1.2;

a0 = hyp; b0 = hyp;
 
% init 
x_pn = sparse(reshape(data, P, numTotal));

isLik = false;
useHistory = false;
if useHistory
    fprintf('use history initialization \n');
    v2struct(history_old);
else 
    fprintf('use random initialization \n');
    %ZZip = rand(K,numTotal)>0.5;
    initTopic = randsample(1:K,numTotal,true);
    ZZip = ind2vec(initTopic);
    ZZip = ZZip + (rand(K,numTotal)<0.1);
    Psi = randg(alpha_psi,P,K); Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
    rk = randg(rk_a,K,1)./rk_b;
    theta = 0+full(ZZip);
%     Phi = randg(alpha_phi,K,K); Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
%     sk = randg(sk_a,K,1).*sk_b;
%     W = ones(K,numTotal);
    Pi_k = betarnd(a0,b0,K,1);   
end
ZZip = sparse(ZZip);
 
% issue : rk,sk: next to end have error; theta have problem
for iter = 1:(numBurnin + numCollection)
	
	
	%% PFA part
	% x_pikt ~ multi (x_pi:t , lamdbda)
	[ x_pk,x_kn ] = mex_mult_rnd( x_pn, Psi, theta, true(1,numTotal));
%     lix = (x_kn == 0); 
%     [rix,cix] = find(x_kn==0); 

      % z
	% issue: less sparse than orginal
    %ZZip = sample_Z(x_kn, ZZip, p0, rk, Phi,W, sk, p1,C_k1n, Pi_k, numSample);
    ZZip = sample_Z_PFA(x_kn, ZZip, p0, rk, Pi_k, numSample);
    ZZip = sparse(ZZip);
	% sparsity = nnz(ans)/numel(ans);
    % subplot(121); imagesc(ans); subplot(122); imagesc(full(ZZip));
	
	% psi (P*K) ~ Dir     P*K
	Psi = randg(alpha_psi + x_pk);
	Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
	% subplot(121); imagesc(ans); subplot(122); imagesc(Pi);
	% rk (K*1),lk = sum U_kit; sk,uk    
	Lk = mex_crt( x_kn, rk );
	sumbpi = sum(ZZip, 2) * log(1-p0);
    % why??
	rk = randg( rk_a + Lk )./( rk_b - sumbpi );
	
	% theta(K*NT)  ZZip (K,NT) 
    %which one is correct??
    %theta = randg( bsxfun( @plus, rk, x_kn )) .* p0;
    theta = randg( bsxfun( @times, rk, ZZip ) + x_kn ) .* p0;
   % gamrnd(x_kn + bsxfun(@times,ZZip,rk),ones(K,numTotal)*p0);	
    % subplot(121); imagesc(ans); subplot(122); imagesc(theta);
    % norm(theta-ans);
    
    
    
    %% dynamic part
	% phi(K*K')  Zk't-1 - > Zkt, c    ZZip1 (k,N(T-1))  C_kn    the rear one   
% 	C_kn = mex_tpo (ZZip, Phi, W);
%     [C_kk1,C_k1n ] = mex_mult_rnd (C_kn, Phi, W, ones(1,numTotal));
%     Phi = randg(alpha_phi + C_kk1);
% 	Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
% 	
% 	% sk
%     Lk = mex_crt( C_k1n, sk );
% 	sumbpi = sum(ZZip, 2) * log(1-p1);
% 	sk = randg( sk_a + Lk )./ ( sk_b - sumbpi );  
%     
%     % w (K,NT)
%     W = randg( bsxfun( @plus, sk, C_k1n )) .* p1;
%     %W = randg( bsxfun( @times, sk, ZZip ) + C_k1n ) .* p1;
%     %w = gamrnd(C_k1n + bsxfun(@times,ZZip,sk),ones(K,numTotal)*p1);	
%     % subplot(121); imagesc(ans); subplot(122); imagesc(W);
%    
    % pi
    %t1_ix = 1:numTime:numTotal;
    %Pi_k = betarnd(a0 + sum(ZZip(:,:),2),b0 + numSample - sum(ZZip(:,t1_ix),2));
    Pi_k = betarnd(a0 + sum(ZZip,2),b0 + numSample*numTime - sum(ZZip,2));

    
    
  
    
    %reconstruction error
    nz = (x_pn ~= 0);
    lambda = Psi*theta;  % p*n
    RMSE = sum(sum((x_pn(nz) - lambda(nz)).^2))/numSample;
    lambda_avg = bsxfun(@rdivide,lambda,sum(lambda,1));
    negLL = -full(sum(x_pn(nz).*log(lambda_avg(nz)))/sum(x_pn(nz)));
   
    % subplot(121); imagesc(x_pn); subplot(122); imagesc(full(lambda));
    
    % negLL = sum(sum((dataZip - D*S).^2))*phi_p/2/numSample + (log(2*3.1415926)-log(phi_p))/2;
    % display
     fprintf('Iter:%d     RMSE:%5g    negLL:%5g  sparsity: %2g\n',iter,RMSE,negLL, nnz(ZZip)/numel(ZZip));
    if iter > numBurnin
        history.var{iter-numBurnin} = v2struct(ZZip,Psi,rk,theta,Pi_k);
    end
     history.sparsity(iter) = nnz(ZZip)/numel(ZZip);
     history.RMSE(iter) = RMSE;
     history.negLL(iter) = negLL;
   
end 
 
 
 
 
 
 
 
 










   
        
