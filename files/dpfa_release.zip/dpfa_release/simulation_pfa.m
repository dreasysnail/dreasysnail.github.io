function [train_data,test_data,train_model,test_model] = simulation_pfa(P, numTime,numSample,numTest, K)
    close all; addpath('tools');
    numTotal = numTime *(numSample+numTest);
    % hypers
    alpha_psi = 0.3;
    p0 = 0.5;
    rk_a = 1.2;
    rk_b = 1/1.2;

    alpha_phi = 0.3;
    p1 = 0.5;
    sk_a = 1.2;
    sk_b = 1/1.2;
    
    a0 = 1; b0 = 1;
    
    % init
    ZZip = rand(K, numTotal)<0.5;
	Psi = randg(alpha_psi, P, K); Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
    rk = randg(rk_a,K,1)*rk_b;   % K*1
    theta = randg(repmat(rk,1,numTotal),K,numTotal) .* (p0/(1-p0));    % K*TN 
    
    Phi = randg(alpha_phi, K, K); Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
    sk = randg(sk_a,K,1)*sk_b;   % K*1
    W = randg(repmat(sk,1,numTotal),K,numTotal) .* (p1/(1-p1));    % K*TN 
    
    Pi_k = betarnd(a0,b0,K,1);
    idx1 = 1:numTime:numTime*numSample;
    ZZip(:,idx1) = sparse(rand(K,numSample)< repmat(Pi_k,1,numSample));
%    BPL = @(lambda) (1 - exp(-lambda));
%     for i = 1:numTime-1
%         lambda = Phi*(ZZip(:,idx1+i-1).*W(:,idx1+i-1));  % k*1
%         ZZip(:,idx1+i) = rand(K,numSample)< BPL(lambda);
%     end

    lambda2 = Psi*(ZZip.*theta);
    data = poissrnd(lambda2);
    train_idx = 1:numSample*numTime;
    test_idx = numSample*numTime+1:numTotal;
    fieldName = {'fieldnames','ZZip','Psi','rk','theta','Phi','sk','W','Pi_k'};
    train_model = v2struct(ZZip(:,train_idx),Psi,rk,theta(:,train_idx),Phi,sk,W(:,train_idx),Pi_k,fieldName);
    test_model = v2struct(ZZip(:,test_idx),Psi,rk,theta(:,test_idx),Phi,sk,W(:,test_idx),Pi_k,fieldName);
    data = reshape(data,P,numTime,numSample+numTest);
    train_data = data(:,:,1:numSample);
    test_data = data(:,:,numSample+1:numSample+numTest);