function ZZip = update_Z(z0,ZZip,numTime)
    [K,numTotal] = size(ZZip);
    t1_ix = 1:numTime:numTotal;
    ZZip = [zeros(K,1),ZZip(:,1:end-1)];
    ZZip(:,t1_ix) = z0;
end
    
    