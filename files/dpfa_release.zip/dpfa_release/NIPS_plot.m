load('1000FullNIPS.mat');
numBurnin = 200; K = 50;
[mp, pp,pm,history] = evaluation(data_collapsed,K,numBurnin);

meanTheta = 0; meanPsi = 0; meanRk = 0;
for i = 1:numCollection
    meanTheta = meanTheta + history.var{i}.theta;
    meanPsi = meanPsi + history.var{i}.Psi;
    meanRk = meanRk + history.var{i}.rk;
end
meanTheta = meanTheta/numCollection;
meanPsi = meanPsi/numCollection;
meanRk = meanRk/numCollection;

[~,topword.toptopicid] = sort(meanRk,'descend');

[topword.prop,topword.id] = sort(meanPsi(:,topword.toptopicid),1,'descend');

topword.word = words(topword.id);

for i = 1:K
    topword.top{i} = strjoin(topword.word(1:5,i)');
end

% [toptop.prop,toptop.id] = sort(history.var{end}.Phi(:,topword.toptopicid),1,'descend');
% 
% toptop.top = topword.top(toptop.id);




for topId = 1:40
    plot(linspace(1987,2003,size(meanTheta,1)),meanTheta(topword.toptopicid{topId},:)); 
%     for i = 1:numCollection
%         meanPZZip = meanPZZip + history.var{i}.pZZip(topword.toptopicid(topId),:);
%     end    
%     plot(linspace(1987,2003,length(meanPZZip)),meanPZZip/numCollection); 
    title(topword.toptopicid{topId}); xlim([1987 2003]);xlabel('Time ordered document','FontSize',16);ylabel('Topic intensity','FontSize',16);
    print(['figs/topic_NIPS',num2str(topId)],'-djpeg','-r300');
end
imagesc(meanTheta);
