#include <stdio.h>

// Matrices are stored in row-major order:
// M(row, col) = *(M.elements + row * M.width + col)

//matrix def
typedef struct {
int width;
int height;
float* elements;   // by row 
} Matrix;

typedef struct {
int width;
int height;
int* elements;   // by row
} Matrix_i;



//#define BLOCK_SIZE 8
// block size of 32*32 = 1024 is suit for GPU compute capability above 2.0

__global__ void multi_kernal(int* const, int* const, const Matrix, const Matrix, Matrix_i, Matrix_i, const Matrix_i, const Matrix_i, Matrix);
