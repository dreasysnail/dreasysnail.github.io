%evaluation
function [pr,pp,pm,history] = evaluation(data,K,numBurnin)
    %data = STOU.WCmatrix;
    numSample = 1;
    AVGSTEPS =5;
    holdoutRate =  0.2;
    ObserveRatio = 1;
    [P, numTime] = size(data);
%     tdata = binornd(data(:,1:end-1),1-holdoutRate);
%     hdata = data(:,1:end-1) - tdata;
%     pdata = data(:,end);
%     history = gibbs_DPFA(tdata,K,numBurnin);
    timeSelect = sort(randsample(1:numTime-1,floor(ObserveRatio*numTime)-1,false));
    timeMiss = setdiff(1:numTime-1,timeSelect);
    timeSpan = diff(timeSelect);
    [~,timeNeighbor] = sort(abs(repmat(timeMiss',1,length(timeSelect))-repmat(timeSelect,length(timeMiss),1)),2);
    tdata = binornd(data(:,timeSelect),0.8);
    hdata = data(:,timeSelect) - tdata;
    pdata = data(:,end);
    mdata = data(:,timeMiss);
    history = gibbs_DPFA(tdata,K,numBurnin,timeSpan);
    %history = gibbs_DPFA(tdata,K,numBurnin,false,history.var{end});
    
    
    


    
    numCollection = length(history.var);
    range = 100;  
    lambda = zeros(P,size(history.var{1}.theta,2)-1);
    for i = 1:numCollection
        var = history.var{i};
        lambda = lambda + var.Psi*var.theta(:,1:end-1);
        %lambda = lambda + var.Psi*(mean(var.theta(:,end-5:end-1),2))
    end
    lambda = lambda/numCollection;
    pr_perp = exp(-sum(sum(hdata.*log(bsxfun(@rdivide, lambda,sum(lambda,1)))))/sum(sum(hdata)));
    [~,cpred] = sort(lambda, 1,'descend' );
    [~,ctrue] = sort(hdata, 1, 'descend' );
    %[~,ctrue] = sort(data(:,timeSelect), 1, 'descend' );
    for t = 1:size(history.var{1}.theta,2)-1
        %mp
        g1 = zeros(P,1); g2 = zeros(P,1);
        g1(ctrue(1:range,t),1) = 1;
        g2(cpred(1:range,t),1) = 1;
        con = confusionmat(g1,g2);
        TNR(t) = con(2,2)/(con(2,2)+con(1,2));
%         T = find( hdata(:,t) ~= 0  );
%         C = intersect(T, cpred(1:range, t) );
%         % C = setdiff(cpred(1:range, t), intersect(T, cpred(1:range, t) ));
%         TPR(t) = length(C)/length(T);
    end
    pr = mean(TNR); %rc =  mean(TPR);
    





    %% pp
    lambda = zeros(P,1);
    for i = 1:numCollection
        var = history.var{i};
%         lambda2 = var.Phi*full(var.ZZip(:,end));
%         %sk = randg(hyp,K,1)/hyp;
%         %W = randg(sk.*full(var.ZZip(:,end)));
%         BPL = @(lambda) (1 - exp(-lambda));
%         %generate zpred
%         zpred = rand(K,1)<BPL(lambda2);
%         %rk = randg(hyp,K,1)/hyp;
%         %theta = randg(rk.*zpred);
%         %lambda = var.Psi*theta;
         lambda = lambda + var.Psi*(mean(var.theta(:,end-AVGSTEPS:end-1),2));
%         %lambda = var.Psi*zpred;
%          lambda = lambda + var.Psi* (var.theta(:,end));
%          lambda = lambda + var.XPred;
    end
    lambda = lambda/numCollection;
    pp_perp = exp(-(sum(pdata.*log(lambda./sum(lambda))))/sum(pdata));
    [~,cpred] = sort(lambda,1, 'descend' );
    [~,ctrue] = sort(pdata,1, 'descend' );
    range = 50; c = intersect(cpred(1:range),ctrue(1:range)) ;
    pp = length(c)/range;
    
    
    % topword.pred = STOU.words(cpred);
    % topword.truth = STOU.words(ctrue);
    
    
    
    
   % pred miss
    if length(timeMiss) == 0
        pm = 0;
    else
        numNeighbor = 4;
        lambda = zeros(size(mdata));
        for t = 1:length(timeMiss)
            for i = 1:numCollection
                var = history.var{i};
        %         lambda2 = var.Phi*full(var.ZZip(:,end));
        %         %sk = randg(hyp,K,1)/hyp;
        %         %W = randg(sk.*full(var.ZZip(:,end)));
        %         BPL = @(lambda) (1 - exp(-lambda));
        %         %generate zpred
        %         zpred = rand(K,1)<BPL(lambda2);
        %         %rk = randg(hyp,K,1)/hyp;
        %         %theta = randg(rk.*zpred);
        %         %lambda = var.Psi*theta;
                  lambda(:,t) = lambda(:,t) + var.Psi*(mean(var.theta(:,timeNeighbor(t,1:numNeighbor)),2));
        %         %lambda = var.Psi*zpred;
        %          lambda = lambda + var.Psi* (var.theta(:,end));
        %          lambda = lambda + var.XPred;
            end
            lambda(:,t) = lambda(:,t)/numCollection;
            [~,cpred] = sort(lambda(:,t),1, 'descend' );
            [~,ctrue] = sort(mdata(:,t),1, 'descend' );
            range = 50; c = intersect(cpred(1:range),ctrue(1:range)) ;
            pc(t) = length(c)/range;
        end  
        pm_perp = exp(-sum(sum(mdata.*log(bsxfun(@rdivide, lambda,sum(lambda,1)))))/sum(sum(mdata)));
        pm = mean(pc);
    end
    clear c cpred ctrue g1 g2 TNR TPR pc i t
    
    