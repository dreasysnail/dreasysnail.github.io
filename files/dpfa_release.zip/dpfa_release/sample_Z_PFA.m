function ZZip = sample_Z_PFA(x_kn, ZZip, p0, rk, Pi_k, numSample)
    %numTime = size(ZZip,2)/numSample;
    %K = size(ZZip,1);

    lix = (x_kn == 0);
    % rix index k
    [rix, ~] = find( x_kn == 0 );
    % calculate Pi
%     BPL = @(lambda) (1 - exp(-lambda));
    % be careful
%     lambda = Phi * (ZZip.* W);
%     Pi = BPL(lambda);
%     Pi = [zeros(K,1), Pi(:,1:end-1)];
%     Pi = 0.5*ones(size(ZZip));
%     t1_ix = 1:numTime:numSample*numTime;
%     Pi(:,t1_ix) = repmat(Pi_k,1,numSample);
%    Pi = repmat(Pi_k,1,numSample*numTime);
    
    % t= 1:numTime-1 
    %p1 = Pi(rix).*( ( 1 - this.pn(cix)'  ).^this.rk(rix) );
%     p_1 = Pi(lix).*( ( 1 - p0 ).^rk(rix) );   
%     p_0 = 1 - Pi(lix);
    
    p_1 = Pi_k(rix).*( ( 1 - p0 ).^rk(rix) );   
    p_0 = 1 - Pi_k(rix);

    ZZip = ones(size(x_kn));
    ZZip(lix) =  (p_1./( p_1 + p_0 ) ) > rand( size( rix )) ;
    imagesc(ZZip);drawnow;
    




