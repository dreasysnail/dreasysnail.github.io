function [train_data,test_data,train_model,test_model,train_labels,test_labels] = simulation_dpfa(P, numTime,numSample,numTest, K,numClass)
    close all; addpath('tools');
    numTotal = numTime *(numSample+numTest);
    % hypers
    alpha_psi = 0.8;
    p0 = 0.5;
    rk_a = 3;
    rk_b = 1/1.2;

    alpha_phi = 0.8;
    p1 = 0.5;
    sk_a = 3;
    sk_b = 1/1.2;
    
    a0 = 1; b0 = 1;
    
    % init
    ZZip = zeros(K, numTotal);
    Pi_k = betarnd(a0,b0,K,1);
    z0 = rand(K,(numSample+numTest))< repmat(Pi_k,1,(numSample+numTest));
    
    Phi = randg(alpha_phi, K, K); Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
    sk = randg(sk_a,K,1)*sk_b;   % K*1
    
    
    BPL = @(lambda) (1 - exp(-lambda));
    idx1 = 1:numTime:numTotal;
    W = zeros(K, numTotal);
    for i = 1:numTime
        if i == 1
            W(:,idx1+i-1) = randg(bsxfun(@times,sk,z0)).* (p1/(1-p1));    % K*TN 
        else
            W(:,idx1+i-1) = randg(bsxfun(@times,sk,ZZip(:,idx1+i-2))).* (p1/(1-p1));    % K*TN 
        end
        lambda = Phi*W(:,idx1+i-1);  % k*1
        ZZip(:,idx1+i-1) = rand(K,numSample+numTest)< BPL(lambda);
    end
    Psi = randg(alpha_psi, P, K); Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
    rk = randg(rk_a,K,1)*rk_b;   % K*1
    theta = randg(bsxfun(@times,rk,ZZip),K,numTotal) .* (p0/(1-p0));    % K*TN 
    % classification
    alpha_b = 2;
    B = randg(alpha_b, numClass, K);  B = bsxfun(@rdivide, B, sum(B,1));
    [~,labels] = max(B*theta,[],1);
    train_labels = labels(1:numSample*numTime);
    test_labels = labels(numSample*numTime+1:end);
    
    
    
    lambda2 = Psi*theta;
    data = poissrnd(lambda2);
    train_idx = 1:numSample*numTime;
    test_idx = numSample*numTime+1:numTotal;
    fieldName = {'fieldnames','ZZip','z0','Psi','rk','theta','Phi','sk','W','Pi_k','B'};
    train_model = v2struct(ZZip(:,train_idx),z0(:,1:numSample),Psi,rk,theta(:,train_idx),Phi,sk,W(:,train_idx),Pi_k,B,fieldName);
    test_model = v2struct(ZZip(:,test_idx),z0(:,numSample+1:end),Psi,rk,theta(:,test_idx),Phi,sk,W(:,test_idx),Pi_k,B,fieldName);
    data = reshape(data,P,numTime,numSample+numTest);
    train_data = data(:,:,1:numSample);
    test_data = data(:,:,numSample+1:numSample+numTest);
    
    assert(numClass == length(unique(train_labels)));
    

    
    
    
    

    