%dynamic PFA

K = 50;
isLik = false;
numBurnin = 900;
load('nips_eval.mat');
data_full = full(data);
clear data;
data = data_full;


%history = gibbs_DPFA(data,K,numBurnin);
%history = gibbs_DPFA(data,K,numBurnin,false,history.var{end});



% NIPS
K = 100;
docs_year = [];
for i = 1:size(docs_names,2)
    docs_year(i) = str2num(docs_names{i}(1:4));
end
data_collapsed = zeros(14036,2003-1987+1);
for i = 1:size(data,2) 
    idx = docs_year(i) - 1987 + 1; 
    data_collapsed(:,idx) = data_collapsed(:,idx) + data(:,i);
end
data_collapsed = sparse(data_collapsed);
%history = gibbs_DPFA(data_collapsed,K,numBurnin);
numBurnin = 200;
[mp, pp,pm,history] = evaluation(data_collapsed,K,numBurnin);


%{

% with time span
numTime = size(data,2);
timeSelect = sort(randsample(1:numTime-1,floor(0.5*numTime),false));
timeMiss = setdiff(1:numTime-1,timeSelect);
timeSpan = diff(timeSelect);
[~,timeNeighbor] = sort(abs(repmat(timeMiss',1,length(timeSelect))-repmat(timeSelect,length(timeMiss),1)),2);
tdata = binornd(data(:,timeSelect),0.8);
hdata = data(:,timeSelect) - tdata;
pdata = data(:,end);
mdata = data(:,timeMiss);
history = gibbs_DPFA(tdata,K,numBurnin,timeSpan);
%history = gibbs_DPFA(data(:,timeSelect),K,numBurnin,timeSpan);




%}











%{
%Dynamic poisson factor model
P = 1000;
numTime = 40;
numSample = 100;
numTest = 500;
K = 30;
isLik = false;
numBurnin = 100;
numClass = 10;
numCollection = 20;
% simulation
[train_data,test_data,train_model,test_model,train_labels,test_labels] = simulation_dpfa(P, numTime,numSample,numTest, K, numClass);
% [train_data,test_data,train_model,test_model] = simulation_pfa(P, numTime,numSample,numTest, K);

%data_sparsity = nnz(data)/numel(data);
% gibbs

isDis = true;
history = gibbs_DPFA(train_data,K,numBurnin,isLik,train_model,true,train_labels);
B.avg = zeros(size(history.var{1}.B));
for ii = 1:numCollection
    B.avg = B.avg + history.var{ii}.B;
end
B.avg = B.avg/numCollection;


[~,test_prediction] = max(B.avg * test_model.theta, [],1);
pred_acc = sum(test_prediction == test_labels)/length(test_labels);
[~,train_prediction] = max(B.avg * train_model.theta, [],1);
train_acc = sum(train_prediction == train_labels)/length(train_labels);
%debug
%history_pfa = gibbs_PFA(train_data,K,numBurnin,isLik,train_model);
subplot(211);imagesc(history.var{1}.B);subplot(212);imagesc(train_model.B);
%}

% STU
% data = STOU.WCmatrix;




%{

history_pfa = gibbs_PFA(data,K,numBurnin);

[~,topword.toptopicid] = sort(history.var{end}.rk,'descend');

[topword.prop,topword.id] = sort(history.var{end}.Psi(:,topword.toptopicid),1,'descend');

%topword.word = STOU.words(topword.id);
topword.word = words(topword.id);

for i = 1:K
    topword.top{i} = strjoin(topword.word(1:5,i)');
end

%subplot(121);imagesc(history.var{end}.theta);subplot(122);imagesc(history_pfa.var{end}.ZZip);

[toptop.prop,toptop.id] = sort(history.var{end}.Phi(:,topword.toptopicid),1,'descend');

toptop.top = topword.top(toptop.id);

%imagesc(history.var{end}.theta(topword.toptopicid,:));xlabel('Time ordered document','FontSize',16);ylabel('Topics','FontSize',16);

for topId = 1:40
    meanTheta = 0;
    for i = 1:numCollection
        meanTheta = meanTheta + history.var{i}.theta(topword.toptopicid(topId),:);
    end
    plot(linspace(1987,2003,length(meanTheta)),meanTheta/numCollection); 
    title( topword.top{topId}); xlim([1987 2003]);xlabel('Time ordered document','FontSize',16);ylabel('Topic intensity','FontSize',16);
    print(['figs/topic_NIPS',num2str(topId)],'-djpeg','-r300');
end
clustergram(history.var{end}.theta(topword.toptopicid,:),'RowLabels',[],'cluster','column','Colormap','gray');
% eva

[pr, pp] = evaluation(data,K,numBurnin);
%}




