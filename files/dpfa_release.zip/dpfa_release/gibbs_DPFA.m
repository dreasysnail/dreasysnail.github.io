function history = gibbs_DPFA(data,K,numBurnin,timeSpan,history_old,isDis,labels)
close all; addpath('tools');
% preprocess
if ismatrix(data)
    numSample = 1;
    [P, numTime] = size(data);
    data = cat(2,data,mean(data,2));
else
    [P, numTime, numSample ] = size(data);
    data = cat(2,data,mean(data,2));
end
numTotal = (numTime + 1) * numSample;
if nargin < 4 || all(timeSpan == false)
    isTime = false;  
else
    isTime = true;  
    assert(length(timeSpan)==numTime-1);
    timeSpan = [1,timeSpan,1];
end
if nargin < 5 || isempty(history_old);
    useHistory = false;
else
    useHistory = true;
end
if nargin < 6
    isDis = false;
end


isFixW = false;
% is discriminative


numCollection= 100;

% hypers
alpha_psi = 0.1;
p0 = 0.8;
rk_a = 1e2; %1e2
rk_b = 1/rk_a;

alpha_phi = 0.01;
p1 = 0.5;
sk_a = 1e5; %1e5
sk_b = 1/sk_a;

a0 = 1; b0 = 1;



% hyp = 3e-1;
% 
% alpha_psi = hyp;
% p0 = 0.5;
% rk_a = hyp;
% rk_b = 1/hyp;
% 
% alpha_phi = hyp;
% p1 = 0.5;
% sk_a = hyp;
% sk_b = 1/hyp;
% 
% a0 = hyp; b0 = hyp;

BPL = @(lambda) (1 - exp(-lambda)); 
% init 

x_pn = sparse(reshape(data, P, numTotal));

if isDis
    numTotal2 = numSample*numTime;
    assert(length(labels) == numTotal2);
    alpha_b = 0.1;
    numClass = length(unique(labels));
    %yy = repmat(labels(:)',1,numTime);
    yy = labels;
    y_cn = sparse(yy(:),1:numTotal2,ones(1,numTotal2));
    avg_y = mean(y_cn,2);
    y_cn = reshape([reshape(y_cn,[],numSample);round(repmat(avg_y,1,numSample))],numClass,[]);
else
    y_kn = sparse(zeros(K,numTotal));
end


if useHistory
    fprintf('use history initialization \n');
    v2struct(history_old);
    tn_ix = (numTime+1):(numTime+1):numTotal;
    %predict future data
    %x_pn(:,tn_ix) = XPred;
    Xpred = round(x_pn(:,tn_ix));
    % add to back, last time point
    ZZip = reshape([reshape(ZZip,[],numSample);zeros(K,numSample)],K,[]);
    theta = reshape([reshape(theta,[],numSample);zeros(K,numSample)],K,[]);
    W = reshape([reshape(W,[],numSample);zeros(K,numSample)],K,[]);
    ZZip2 = update_Z(z0,ZZip,numTime+1);

else 
    fprintf('use random initialization \n');
    %initTopic = randsample(1:K,numTotal,true);
    %ZZip = ind2vec(initTopic);
    %ZZip = ZZip + (rand(K,numTotal)<1);
    ZZip = (rand(K,numTotal)<1);
    z0 = ones(K,numSample);
    Psi = randg(alpha_psi,P,K); Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
    %rk = randg(rk_a,K,1).*rk_b;
    rk = zeros(K,1);
    theta = 0+full(ZZip);
    Phi = randg(alpha_phi,K,K); Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
    %sk = randg(sk_a,K,1).*sk_b;
    sk = zeros(K,1);
    ZZip2 = update_Z(z0,ZZip,numTime+1);
    W = 0+full(ZZip2);
    Pi_k = betarnd(a0,b0,K,1); 
    if isDis
        alpha_b = 1;
        B = randg(alpha_b, numClass, K); B = bsxfun(@rdivide, B, sum(B,1));
    end
%     Wn = 0+full(ZZip(:,end));
%     ZPred = rand(K,1)<BPL(Phi*Wn);
%     thetaPred = 0 + Zpred;
%     XPred = poissrnd(BPL(Psi*thetaPred));
end
ZZip = sparse(ZZip);
if isTime
    p1m = repmat(p1./(p1+(1-p1)*timeSpan),1,numSample); % 1*numTotal
end

% issue : rk,sk: next to end have error; theta have problem
for iter = 1:(numBurnin + numCollection)
	
	
	%% PFA part
	% x_pikt ~ multi (x_pi:t , lamdbda)
    % issue first line all one when hyp is small
	[ x_pk,x_kn ] = mex_mult_rnd( x_pn, Psi, theta, true(1,numTotal));
%     lix = (x_kn == 0); 
%     [rix,cix] = find(x_kn==0); 
    if isTime
        C_kn = mex_tpo (ZZip, Phi, bsxfun(@rdivide,W,timeSpan));  
    else
        C_kn = mex_tpo (ZZip, Phi, W);
    end
    [C_kk1,C_k1n ] = mex_mult_rnd (C_kn, Phi, W, ones(1,numTotal));
    
    if isDis
        [ y_ck, y_kn ] = mex_mult_rnd( y_cn, B, theta, true(1,numTotal));
        B = randg(alpha_b + y_ck);
	    B = bsxfun( @rdivide, B, sum( B, 1 ) );
        %extend to z0
        %y_kn = reshape([zeros(K,numSample);reshape(y_kn,[],numSample)],K,[]);
    end
    % z
	% issue: less sparse than orginal
    % y_kn indicate discriminative task
    if isTime
        [ZZip, z0, pZZip] = sample_Z_timespan(x_kn , p0, rk, Phi,W, sk, p1m,C_k1n, Pi_k, numSample,timeSpan,y_kn);
    else
        [ZZip, z0, pZZip] = sample_Z(x_kn , p0, rk, Phi,W, sk, p1,C_k1n, Pi_k, numSample,y_kn);
    end
    % z0+ZZip = ZZip2 + Z(end)
    ZZip2 = update_Z(z0,ZZip,numTime + 1);
    
    %do again
%     if isTime
%         C_kn = mex_tpo (ZZip, Phi, bsxfun(@rdivide,W,timeSpan));  
%     else
%         C_kn = mex_tpo (ZZip, Phi, W);
%     end
%     [C_kk1,C_k1n ] = mex_mult_rnd (C_kn, Phi, W, ones(1,numTotal));

     
	% sparsity = nnz(ans)/numel(ans);
    % subplot(121); imagesc(full(ans)); subplot(122); imagesc(full(ZZip));
	
	% psi (P*K) ~ Dir     P*K
	Psi = randg(alpha_psi + x_pk);
	Psi = bsxfun( @rdivide, Psi, sum( Psi, 1 ) );
	% subplot(121); imagesc(ans); subplot(122); imagesc(Pi);
	% rk (K*1),lk = sum U_kit; sk,uk    
	Lk = mex_crt( x_kn, rk );
	sumbpi = sum(ZZip, 2) * log(1-p0);
    % why??
	rk = randg( rk_a + Lk )./( 1/rk_b - sumbpi );
	
	% theta(K*NT)  ZZip (K,NT) 
    %which one is correct??
    %theta = randg( bsxfun( @plus, rk, x_kn )) .* p0;

   % gamrnd(x_kn + bsxfun(@times,ZZip,rk),ones(K,numTotal)*p0);	
    % subplot(121); imagesc(ans); subplot(122); imagesc(theta);
    % norm(theta-ans);

    
    if ~isFixW
        if isDis
            theta = randg( bsxfun( @times, rk, ZZip ) + x_kn + y_kn ) .* p0;
        else
            theta = randg( bsxfun( @times, rk, ZZip ) + x_kn ) .* p0;
        end
    else
        theta = full(ZZip);
    end
    
    
    %% dynamic part
	% phi(K*K')  Zk't-1 - > Zkt, c    ZZip1 (k,N(T-1))  C_kn    the rear one   
    Phi = randg(alpha_phi + C_kk1);
	Phi = bsxfun( @rdivide, Phi, sum( Phi, 1 ) );
	% subplot(121); imagesc(ans); subplot(122); imagesc(Phi);
    
    %ZZip2   z0: zn-1

	% sk
    Lk = mex_crt( C_k1n, sk );
    if isTime
        sumbpi = ZZip2*log(1-p1m');
    else
        sumbpi = sum(ZZip2, 2) * log(1-p1);
    end
	sk = randg( sk_a + Lk )./ ( 1/sk_b - sumbpi );  
    
    % w (K,NT)
    if ~isFixW
        if isTime
            W = bsxfun(@times, randg( bsxfun( @times, sk, ZZip2 ) + C_k1n ),p1m.*timeSpan);
        else
            W = randg( bsxfun( @times, sk, ZZip2 ) + C_k1n ) .* p1;
        end
    else
        W = full(ZZip2);
    end

    % subplot(121); imagesc(ans); subplot(122); imagesc(W);
   
    % pi
    %t1_ix = 1:numTime:numTotal;
    Pi_k = betarnd(a0 + sum(z0,2),b0 + numSample - sum(z0,2));
    

    % one step prediction
    tn_ix = (numTime+1):(numTime+1):numTotal;
    XPred = poissrnd(Psi*theta(:,tn_ix));
    x_pn(:,tn_ix) = XPred;

    
    %reconstruction error
    nz = (x_pn(:,1:numTime) ~= 0);
    lambda = Psi*theta(:,1:numTime);  % p*n
    RMSE = sum(sum((x_pn(nz) - lambda(nz)).^2))/numSample;
    lambda_avg = bsxfun(@rdivide,lambda,sum(lambda,1));
    negLL = -full(sum(x_pn(nz).*log(lambda_avg(nz)))/sum(x_pn(nz)));
   
 %   subplot(121); imagesc(W); subplot(122); imagesc(theta);drawnow;
    subplot(221); imagesc(Phi); subplot(222); imagesc(Psi);
    subplot(223); imagesc(pZZip(:,end-10:end)); subplot(224); imagesc(theta(:,end-10:end));drawnow;

    % negLL = sum(sum((dataZip - D*S).^2))*phi_p/2/numSample + (log(2*3.1415926)-log(phi_p))/2;
    % display
    fprintf('Iter:%d     RMSE:%5g    negLL:%5g  sparsity: %2g\n',iter,RMSE,negLL, nnz(ZZip)/numel(ZZip));
   
    if iter > numBurnin
        if isDis
            history.var{iter-numBurnin} = v2struct(ZZip,pZZip,Psi,rk,theta,Phi,sk,W,Pi_k,XPred,B);
        else
            history.var{iter-numBurnin} = v2struct(ZZip,pZZip,Psi,rk,theta,Phi,sk,W,Pi_k,XPred);
        end
    end
    history.sparsity(iter) = nnz(ZZip)/numel(ZZip);
    history.RMSE(iter) = RMSE;
    history.negLL(iter) = negLL;
   
end 
 
 
 
 
 
 
 
 










   
        
